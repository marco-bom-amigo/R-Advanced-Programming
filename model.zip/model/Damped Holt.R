# Phi auto generated
Phi <- holt(train, h = 19, damped = T)
f <- forecast(Phi, h = 19)

dates$Damped.Holt <- c(Phi$fitted, Phi$mean)

error <- test - Phi$mean

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- rbind(result, data.frame(Model = 'Damped Holt', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))

