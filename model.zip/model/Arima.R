# Arima auto generated
model <- auto.arima(t)
f <- forecast(model, h = 19)

dates$Arima <- c(model$fitted, model$mean)

error <- test - f$mean

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- rbind(result, data.frame(Model = 'ARIMA', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))

