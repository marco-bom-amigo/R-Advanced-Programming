library(randomForest)

#########
## RFR ##
#########
set.seed(1234)

# 1:746
regressor = randomForest( x = dates[,c("domingo","quarta.feira","quinta.feira","sabado","segunda.feira","sexta.feira","DAT_APURACAO_VENDA","day","month","year","week")]
                        , y = dates[,"QTD_VENDIDA_PROD"]
                        , ntree = 500
                        )
# 747:765
Y_pred = predict(regressor$y, dates[747:765,c("domingo","quarta.feira","quinta.feira","sabado","segunda.feira","sexta.feira","DAT_APURACAO_VENDA","day","month","year","week")])

error <- dates$QTD_VENDIDA_PROD[747:765] - regressor$y[747:765]

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

dates$DTR <- c(regressor$y, Y_pred)
result <- rbind(result, data.frame(Model = 'DTR', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))

