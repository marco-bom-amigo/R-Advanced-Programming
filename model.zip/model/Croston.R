model <- croston(train, h = 19)
f <- forecast(model, h = 19)

dates$Croston <- c(model$fitted, f$mean)

error <- test - f$mean

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- rbind(result, data.frame(Model = 'Croston', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))
