# Exponential smoothing with holt
model <- holt(train, h = 19)
f <- forecast(model, h = 19)

dates$Holt <- c(model$fitted, model$mean)

error <- test - model$mean

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- data.frame(Model = 'Holt', RMSE = rmse, RMSE.P = pos, RMSE.N = neg)

