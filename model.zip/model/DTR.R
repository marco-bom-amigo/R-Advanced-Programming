#########
## DTR ##
#########
regressor = rpart( QTD_VENDIDA_PROD
                 ~ domingo
                 + segunda.feira
                 + quarta.feira
                 + quinta.feira
                 + sexta.feira
                 + sabado
                 + poly(DAT_APURACAO_VENDA, 6)
                 + poly(day, 5)
                 + poly(month, 2)
                 + poly(year, 2)
                 + poly(week, 7)
                 + outlier
                 , data = training_set
                 , control = rpart.control(minsplit = 1)
                 )

Y_pred <- predict(regressor, newdata = test_set)

error <- test - Y_pred

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

dates$DTR <- c(regressor$y, Y_pred)
result <- rbind(result, data.frame(Model = 'DTR', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))

