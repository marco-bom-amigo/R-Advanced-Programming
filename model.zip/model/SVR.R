library("e1071")

regressor <- svm( QTD_VENDIDA_PROD
                ~ domingo
                + segunda.feira
                + quarta.feira
                + quinta.feira
                + sexta.feira
                + sabado
                + poly(DAT_APURACAO_VENDA, 6)
                + poly(day, 5)
                + poly(month, 2)
                + poly(year, 2)
                + poly(week, 7)
                + outlier
                , data = training_set
                , type = 'eps-regression'
                , kernel = 'radial'
                )

Y_pred <- predict(regressor, newdata = test_set)

dates$SVR <- c(regressor$fitted, Y_pred)

error <- test - Y_pred

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- rbind(result, data.frame(Model = 'SVR', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))

