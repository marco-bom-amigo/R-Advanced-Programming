model <- stlf(t, method = "ets")
f <- forecast(model, h = 19)

dates$STL.ETS <- model$fitted

error <- test - f$mean

pos  <- error[error >= 0]
neg  <- error[error < 0]

rmse <- sqrt(mean(error^2))
pos  <- sqrt(mean(  pos^2))
neg  <- sqrt(mean(  neg^2))

result <- rbind(result, data.frame(Model = 'STL + ETS', RMSE = rmse, RMSE.P = pos, RMSE.N = neg))




