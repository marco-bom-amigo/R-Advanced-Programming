#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
library(stringr)
library(forecast)
#################

for (loja in unique(df$codloja)) {
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    #for (plu in unique(df[df$codloja == loja & df$plu %in% df.desc[df.desc$accuracy < 70,]$plu,]$plu)) {
    
    #################
    ## Current Row ##
    #################
    cat(paste('\n', loja, ' | ', plu, sep = ''))
    #################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a <- df[df$codloja == loja & df$plu == plu, c("datvenda", "QTD_VENDIDA_PROD")]
    df.a <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    #########################
    
    ##################
    ## All Dates <3 ##
    ##################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                               , max(df.a$datvenda)
                                               , by = 1
    )
    )
    , df.a
    , all.x = T
    )
    ##################
    
    ###############
    ## Empty ='( ##
    ###############
    df.a$QTD_VENDIDA_PROD[is.na(df.a$QTD_VENDIDA_PROD)] <- 0
    ###############
    
    ###################
    ## Date Features ##
    ###################
    df.a$year  <- year(df.a$datvenda)
    df.a$month <- month(df.a$datvenda)
    df.a$wday  <- as.POSIXlt(df.a$datvenda)$wday
    df.a$day   <- day(df.a$datvenda)
    ###################
    
    df.a$HASH <- as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))
    f <- sort(unique(as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))))
    
    MAPE <- Inf
    for (h in f) {
      df.h <- df.a[df.a$HASH > h,]
      df.h <- df.h[,-length(df.h)]
      
      ##############
      ## Outliers ##
      ##############
      # stats <- boxplot(df.h$QTD_VENDIDA_PROD[df.h$QTD_VENDIDA_PROD > 0], plot = F)$stats
      # row.names(df.h) <- NULL
      # df.out <- df.h[df.h$QTD_VENDIDA_PROD > stats[5],]
      # if (nrow(df.out) > 0) {
      #   for (i in 1:nrow(df.out)) {
      #     mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$wday  == df.out[i,]$wday & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)
      #     if (is.na(mn)) {mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)}
      #     if (!is.na(mn)) {
      #       df.h[as.numeric(row.names(df.out[i,])),]$QTD_VENDIDA_PROD <- mn
      #     }
      #   }; rm(i); rm(mn)
      # }; rm(df.out)
      ###################
      
      if (nrow(df.h) > 7) {
        df.train <- df.h[1:(nrow(df.h)-7),]
        df.test  <- df.h[(nrow(df.h)-6):nrow(df.h),]
      }
      
      if (length(df.train$QTD_VENDIDA_PROD) > 2) {
        mod  <- holt(df.train$QTD_VENDIDA_PROD, h = 7)
        pred <- as.vector(mod$mean)
        real <- df.test$QTD_VENDIDA_PROD
        indx <- real == 0
        pred[pred < 0] <- 0
        pred[indx] <- pred[indx] + 1
        real[indx] <- real[indx] + 1
        if (round(mean((abs(real - pred)/real)) * 100, 2) < MAPE) {
          MAPE <- round(mean((abs(real - pred)/real)) * 100, 2)
        }
        mod <- auto.arima(ts(df.train$QTD_VENDIDA_PROD, frequency = 7), stepwise = T, approximation = F, trace = T)
        pred <- as.vector(forecast(mod, h = 7)$mean)
        real <- df.test$QTD_VENDIDA_PROD
        indx <- real == 0
        pred[pred < 0] <- 0
        pred[indx] <- pred[indx] + 1
        real[indx] <- real[indx] + 1
        if (round(mean((abs(real - pred)/real)) * 100, 2) < MAPE) {
          MAPE <- round(mean((abs(real - pred)/real)) * 100, 2)
        }
      } else {
        MAPE <- Inf
      }

      # mod <- auto.arima(ts(df.train$QTD_VENDIDA_PROD, frequency = 7))
      # pred <- as.vector(forecast(mod, h = 7)$mean)
      # real <- df.test$QTD_VENDIDA_PROD
      # indx <- real == 0
      # pred[pred < 0] <- 0
      # pred[indx] <- pred[indx] + 1
      # real[indx] <- real[indx] + 1
      # if (round(mean((abs(real - pred)/real)) * 100, 2) < MAPE) {
      #   MAPE <- round(mean((abs(real - pred)/real)) * 100, 2)
      # }
      

    }
    cat(paste('\n', MAPE, '\n', sep = ''))
    if (exists('result.holt.o')) {
      result.holt.o <- rbind(result.holt.o, data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE))
    } else {
      result.holt.o <- data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE)
    }
  }
}

write.csv(result.holt.o, 'data/result_holt_o.csv', row.names = F)


