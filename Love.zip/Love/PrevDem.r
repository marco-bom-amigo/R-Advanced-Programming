PrevDem <- read.csv('data/PrevDem.csv', stringsAsFactors = F)

for (loja in unique(PrevDem$COD_LOCAL)) {
  tot <- length(unique(df[df$codloja == loja,]$plu))
  ind <- 0
  for (plu in unique(PrevDem[PrevDem$COD_LOCAL == loja,]$COD_PLU)) {
    ind <- ind + 1
    cat('\n', ind, '/', tot)
    df.a <- data.frame(t(PrevDem[PrevDem$COD_LOCAL == loja & PrevDem$COD_PLU == plu,c(3,4)]))[2,]
    names(df.a) <- as.matrix(data.frame(t(PrevDem[PrevDem$COD_LOCAL == loja & PrevDem$COD_PLU == plu,c(3,4)]))[1,])
    if (!exists('df.prev.dem')) {
      df.prev.dem <- cbind(COD_LOJA = loja, plu = plu, df.a)
    } else {
      if (length(cbind(COD_LOJA = loja, plu = plu, df.a)) == 7) {
        df.prev.dem <- rbind(df.prev.dem, cbind(COD_LOJA = loja, plu = plu, df.a))  
      }
    }
    
  }
}

write.csv(df.prev.dem, 'data/df.prev.dem.csv', row.names = F)
