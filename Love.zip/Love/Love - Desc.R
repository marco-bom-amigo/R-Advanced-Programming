##########
## Read ##
##########
df.desc <- read.csv('data/full.csv', stringsAsFactors = F)

mlr    <- read.csv('data/result_mlr.csv'   , stringsAsFactors = F)
mlr.o  <- read.csv('data/result_mlr_o.csv' , stringsAsFactors = F)
rf     <- read.csv('data/result_rf.csv'    , stringsAsFactors = F)
rf.o   <- read.csv('data/result_rf_o.csv'  , stringsAsFactors = F)
svr    <- read.csv('data/result_svr.csv'   , stringsAsFactors = F)
svr.o  <- read.csv('data/result_svr_o.csv' , stringsAsFactors = F)
holt   <- read.csv('data/result_holt.csv'  , stringsAsFactors = F)
holt.o <- read.csv('data/result_holt_o.csv', stringsAsFactors = F)
a.nn   <- read.csv('data/result_arima_nnetar.csv', stringsAsFactors = F)

df.desc$MAPE.MLR    <- NULL
df.desc$MAPE.MLR.wo <- NULL
df.desc$b.acc       <- NULL
##########

###########
## Names ##
###########
names(mlr)[3]    <- 'MAPE.mlr'
names(mlr.o)[3]  <- 'MAPE.mlr.o'
names(rf)[3]     <- 'MAPE.rfr'
names(rf.o)[3]   <- 'MAPE.rfr.o'
names(svr)[3]    <- 'MAPE.svr'
names(svr.o)[3]  <- 'MAPE.svr.o'
names(holt)[3]   <- 'MAPE.holt'
names(holt.o)[3] <- 'MAPE.holt.o'
names(a.nn)[3]   <- 'MAPE.a.nn'
###########

###########
## Merge ##
###########
df.desc <- merge(df.desc, mlr   , all.x = T)
df.desc <- merge(df.desc, mlr.o , all.x = T)
df.desc <- merge(df.desc, rf    , all.x = T)
df.desc <- merge(df.desc, rf.o  , all.x = T)
df.desc <- merge(df.desc, svr   , all.x = T)
df.desc <- merge(df.desc, svr.o , all.x = T)
df.desc <- merge(df.desc, holt  , all.x = T)
df.desc <- merge(df.desc, holt.o, all.x = T)
df.desc <- merge(df.desc, a.nn, all.x = T)
###########

df.desc$MAPE.a.nn[is.na(df.desc$MAPE.a.nn)] <- 1000

##########
## Best ##
##########
df.desc$b.model <- ''
df.desc$b.acc   <- 0

for (i in 1:nrow(df.desc)) {
  df.desc[i,]$b.model <- names(df.desc)[14:22][which.min(df.desc[i, 14:22])]
  df.desc[i,]$b.acc   <- df.desc[i,which.min(df.desc[i,14:22]) + 13]
}; rm(i)
##########

df.desc$accuracy <- 100 - df.desc$b.acc

quantile(df.desc$accuracy)
boxplot(df.desc$accuracy, plot = F)$stats

table(df.desc$b.model)

write.csv(df.desc, 'data/result.csv', row.names = F)
