#install and load package arules

#install.packages("arules")

library(arules)

#install and load arulesViz

#install.packages("arulesViz")

library(arulesViz)

#install and load tidyverse

#install.packages("tidyverse")

library(tidyverse)

#install and load readxml

#install.packages("readxml")

library(readxl)

#install and load knitr

#install.packages("knitr")

library(knitr)

#load ggplot2 as it comes in tidyverse

library(ggplot2)

#install and load lubridate

#install.packages("lubridate")

library(lubridate)

#install and load plyr

#install.packages("plyr")

library(plyr)

library(dplyr)



#read excel into R dataframe

retail <- read.table("Online_Retail.csv", sep = ';', header = T)

#complete.cases(data) will return a logical vector indicating which rows have no missing values. Then use the vector to get only rows that are complete using retail[,].

retail <- retail[complete.cases(retail), ]





retail$Date <- as.Date(retail$InvoiceDate)

#Extract time from InvoiceDate and store in another variable

retail$InvoiceDate <- as.character(retail$InvoiceDate)

as.Date(retail$InvoiceDate[1:10], format = "%d/%m/%y %h:%m")

retail$InvoiceDateX <- as.POSIXct(retail$InvoiceDate,format="%d/%m/%Y %H:%M")



TransTime <- format(retail$InvoiceDateX,format="%H:%M:%S")

#Convert and edit InvoiceNo into numeric

InvoiceNo <- as.numeric(as.character(retail$InvoiceNo))



#get a glimpse of your data

glimpse(retail)



library(plyr)

#ddply(dataframe, variables_to_be_used_to_split_data_frame, function_to_be_applied)

transactionData <- ddply(retail,c("InvoiceNo","Date"),
                         
                         function(df1)paste(df1$Description,
                                            
                                            collapse = ","))

#The R function paste() concatenates vectors to character and separated results using collapse=[any optional charcater string ]. Here ',' is used



#set column InvoiceNo of dataframe transactionData 

transactionData$InvoiceNo <- NULL

#set column Date of dataframe transactionData

transactionData$Date <- NULL

#Rename column to items

colnames(transactionData) <- c("items")

#Show Dataframe transactionData

head(transactionData)





write.csv(transactionData,"market_basket_transactions.csv", quote = FALSE, row.names = FALSE)



#sep tell how items are separated. In this case you have separated using ','

tr <- read.transactions('market_basket_transactions.csv', format = 'basket', sep=',')

summary(tr)



# Create an item frequency plot for the top 20 items

if (!require("RColorBrewer")) {
  
  # install color package of R
  
  install.packages("RColorBrewer")
  
  #include library RColorBrewer
  
  library(RColorBrewer)
  
}

itemFrequencyPlot(tr,topN=20,type="absolute",col=brewer.pal(8,'Pastel2'), main="Absolute Item Frequency Plot")

itemFrequencyPlot(tr,topN=20,type="relative",col=brewer.pal(8,'Pastel2'), main="Relative Item Frequency Plot")



# Min Support as 0.001, confidence as 0.8.

association.rules <- apriori(tr, parameter = list(supp=0.0005, conf=0.8,maxlen=10))

summary(association.rules)



inspect(association.rules)

