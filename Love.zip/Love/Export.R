###########################
## Set Working Directory ##
###########################
setwd("~/Guia de Produção/Love/data/export")
###########################

for (loja in unique(df$codloja)) {
  for (secao in unique(df[df$codloja == loja,]$NOM_SECAO)) {
    cat(paste('\n', loja, '|', secao, sep = ''))
    write.csv(df[df$codloja == loja & df$NOM_SECAO == secao,], paste(loja, secao, '.csv', sep = '_'), row.names = F)
  }
}
table(df[,c('codloja', 'NOM_SECAO')])


