df <- read.csv('love.df.csv', stringsAsFactors = F)
df$datvenda <- as.Date(df$datvenda)

events <- read.csv('love.events.csv', stringsAsFactors = F)

df.measures <- read.csv('love.measures.csv', stringsAsFactors = F)
#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
#################

#################
## L� os dados ##
#################
setwd("D:/GPA/Love/data")
files <- list.files(path = '.')[1:5]
for (file in files) {
  cat('\n'); cat(file)
  if (!exists('dff')) {
    dff <- read.csv(file, stringsAsFactors = F)
  } else {
    dff <- rbind(dff, read.csv(file, stringsAsFactors = F))
  }
}
df <- dff; rm(df); rm(files); rm(file)
#################

###########
## Pre�o ##
###########
df$preco <- round(df$VAL_TOT_VENDA_PROD / df$QTD_VENDIDA_PROD)
###########

##########
## Date ##
##########
df$datvenda <- as.Date(df$datvenda)
##########

############
## Events ##
############
events <- read.csv('Events.csv', sep = ';', stringsAsFactors = F, encoding = 'utf8')

events$Date <- gsub(' de ', '/',events$Date)
events$Date <- paste(events$Date, events$Year, sep = '/')
events$Date <- dmy(events$Date)

events$Name <- gsub(' ', '_', events$Name)
events$Name <- gsub("'s_Day", '', events$Name)
events$Name <- gsub("[(]", '', events$Name)
events$Name <- gsub("[)]", '', events$Name)
events$Name <- gsub("_Day", '', events$Name)
events$Name <- gsub("_/_May", '', events$Name)
events$Name <- gsub("_/_", '_', events$Name)
events$Name <- gsub("'s", '', events$Name)

unique(events$Name)
############

###############
## Events =) ##
###############
events$Type <- NULL
year    <- unique(events$Year)
feriado <- unique(events$Name)
for (y in year) {
  for (i in feriado) {
    dt <- events[events$Name == i & events$Year == y,]$Date
    for (j in 1:7) {
      if (sum(events$Date == dt - days(j)) == 0) {
        events <- rbind(events, data.frame(Date = dt - days(j), Name = paste(i, 'b', j, sep = '_'), Year = y))  
      }
      if (sum(events$Data == dt + days(j)) == 0) {
        events <- rbind(events, data.frame(Date = dt + days(j), Name = paste(i, 'b', j, sep = '_'), Year = y))  
      }
    }; rm(j)
  }
}
rm(y); rm(i); rm(year); rm(feriado); rm(dt)

events$Year <- NULL
dm <- as.data.frame(dummy(events$Name))
names(dm) <- gsub('Name)', '', names(dm))
events <- cbind(events$Date, dm)
names(events)[1] <- 'Data'
rm(dm)

dt <- unique(events$Data)
for (i in 1:length(dt)) {
  if (exists('df.events')) {
    df.events <- rbind(df.events, data.frame(Data = dt[i], t(colSums(events[events$Data == dt[i],-1]))))
  } else {
    df.events <- data.frame(Data = as.Date(dt[i]), t(colSums(events[events$Data == i,-1])))
  }
}; rm(i)
events <- df.events; rm(df.events); rm(dt)
###############

#############################
## Forecast por PLU e Loja ##
#############################
for (loja in unique(df$codloja)) {
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    
    ######################
    ## Descricao do PLU ##
    ######################
    desc <- list( NOM_SECAO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_SECAO   , 1)
                , NOM_CATEG    = head(df[df$codloja == loja & df$plu == plu,]$NOM_CATEG   , 1)
                , NOM_SUBCATEG = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBCATEG, 1)
                , NOM_GRUPO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_GRUPO   , 1)
                , NOM_SUBGRUPO = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBGRUPO, 1)
                , NOM_PROD     = head(df[df$codloja == loja & df$plu == plu,]$NOM_PROD    , 1)
                )
    ######################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a   <- df[df$codloja == loja & df$plu == plu,]
    df.a.l <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = length); names(df.a.l)[2] <- 'QTD_TRANS'
    df.a.s <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    df.a   <- merge( df.a.l
                   , df.a.s
                   ); rm(df.a.l); rm(df.a.s)
    df.a$MEAN_QTD_VENDIDA_PROD <- df.a$QTD_VENDIDA_PROD / df.a$QTD_TRANS
    #########################
    
    ###########################
    ## Extract Date Features ##
    ###########################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , max(df.a$datvenda)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ###########################
    sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)

    if (exists('df.measures')) {
      df.measures <- rbind(df.measures, data.frame( COD_LOJA     = loja
                                                  , plu          = plu
                                                  , NOM_SECAO    = desc$NOM_SECAO
                                                  , NOM_CATEG    = desc$NOM_CATEG
                                                  , NOM_SUBCATEG = desc$NOM_SUBCATEG
                                                  , NOM_GRUPO    = desc$NOM_GRUPO
                                                  , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                                                  , NOM_PROD     = desc$NOM_PROD
                                                  , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                                                  , N.DAYS       = nrow(df.a)
                                                  , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                                                  , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                                                  , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                                                  )
                          )
    } else {
      df.measures <- data.frame( COD_LOJA     = loja
                               , plu          = plu
                               , NOM_SECAO    = desc$NOM_SECAO
                               , NOM_CATEG    = desc$NOM_CATEG
                               , NOM_SUBCATEG = desc$NOM_SUBCATEG
                               , NOM_GRUPO    = desc$NOM_GRUPO
                               , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                               , NOM_PROD     = desc$NOM_PROD
                               , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                               , N.DAYS       = nrow(df.a)
                               , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                               , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                               , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                               )
    }
    
  }
}; rm(loja); rm(plu); rm(df.a); rm(desc)

