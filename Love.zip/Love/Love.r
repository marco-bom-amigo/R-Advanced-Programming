#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
#################

#################
## Lê os dados ##
#################
df <- read.csv('data/df.csv', stringsAsFactors = F)
#################

###########
## Preço ##
###########
df$preco <- round(df$VAL_TOT_VENDA_PROD / df$QTD_VENDIDA_PROD)
###########

##########
## Date ##
##########
df$datvenda <- as.Date(df$datvenda)
##########

############
## Events ##
############
events <- read.csv('data/Events.csv', sep = ';', stringsAsFactors = F, encoding = 'utf8')
events$Data <- dmy(events$Data)
events$year <- year(events$Data)
events$Feriado <- gsub(' ', '_', events$Feriado)
events$Feriado <- gsub('Confraterniza\U3e37653c\U3e33653co_Universal'       , 'Ano_Novo'                , events$Feriado)
events$Feriado <- gsub('Paix\U3e33653co_de_Cristo'                          , 'Paixao_de_Cristo'        , events$Feriado)
events$Feriado <- gsub('Independ\U3e61653cncia_do_Brasil'                   , 'Independencia'           , events$Feriado)
events$Feriado <- gsub('Nossa_Sr.a\U3e30613cAparecida_-_Padroeira_do_Brasil', 'Nossa_Sra'               , events$Feriado)
events$Feriado <- gsub('Proclama\U3e37653c\U3e33653co_da_Rep\U3e61663cblica', 'Proclamacao_da_Republica', events$Feriado)
############

###############
## Events =) ##
###############
year    <- unique(events$year)
feriado <- unique(events$Feriado)
for (y in year) {
  for (i in feriado) {
    
    min.dt <- min(events[events$Feriado == i & events$year == y,]$Data)
    max.dt <- max(events[events$Feriado == i & events$year == y,]$Data)

    for (j in 1:7) {
      if (sum(events$Data == min.dt - days(j)) == 0) {
        events <- rbind(events, data.frame(Data = min.dt - days(j), Feriado = paste(i, 'b', j, sep = '_'), year = y))  
      }
      if (sum(events$Data == max.dt + days(j)) == 0) {
        events <- rbind(events, data.frame(Data = max.dt + days(j), Feriado = paste(i, 'a', j, sep = '_'), year = y))  
      }
    }; rm(j)
  }
}; rm(y); rm(i); rm(year); rm(feriado); rm(min.dt); rm(max.dt)
events$year <- NULL
dm <- as.data.frame(dummy(events$Feriado))
names(dm) <- gsub('Feriado)', '', names(dm))
events <- cbind(events$Data, dm)
names(events)[1] <- 'Data'
rm(dm)
###############

#############################
## Forecast por PLU e Loja ##
#############################
for (loja in unique(df$codloja)) {
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    
    ######################
    ## Descri??o do PLU ##
    ######################
    desc <- list( NOM_SECAO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_SECAO   , 1)
                , NOM_CATEG    = head(df[df$codloja == loja & df$plu == plu,]$NOM_CATEG   , 1)
                , NOM_SUBCATEG = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBCATEG, 1)
                , NOM_GRUPO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_GRUPO   , 1)
                , NOM_SUBGRUPO = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBGRUPO, 1)
                , NOM_PROD     = head(df[df$codloja == loja & df$plu == plu,]$NOM_PROD    , 1)
                )
    ######################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a   <- df[df$codloja == loja & df$plu == plu,]
    df.a.l <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = length); names(df.a.l)[2] <- 'QTD_TRANS'
    df.a.s <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    df.a   <- merge( df.a.l
                   , df.a.s
                   ); rm(df.a.l); rm(df.a.s)
    df.a$MEAN_QTD_VENDIDA_PROD <- df.a$QTD_VENDIDA_PROD / df.a$QTD_TRANS
    #########################
    
    ###########################
    ## Extract Date Features ##
    ###########################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , max(df.a$datvenda)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ###########################
    sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)

    if (exists('df.measures')) {
      df.measures <- rbind(df.measures, data.frame( COD_LOJA     = loja
                                                  , plu          = plu
                                                  , NOM_SECAO    = desc$NOM_SECAO
                                                  , NOM_CATEG    = desc$NOM_CATEG
                                                  , NOM_SUBCATEG = desc$NOM_SUBCATEG
                                                  , NOM_GRUPO    = desc$NOM_GRUPO
                                                  , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                                                  , NOM_PROD     = desc$NOM_PROD
                                                  , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                                                  , N.DAYS       = nrow(df.a)
                                                  , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                                                  , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                                                  , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                                                  )
                          )
    } else {
      df.measures <- data.frame( COD_LOJA     = loja
                               , plu          = plu
                               , NOM_SECAO    = desc$NOM_SECAO
                               , NOM_CATEG    = desc$NOM_CATEG
                               , NOM_SUBCATEG = desc$NOM_SUBCATEG
                               , NOM_GRUPO    = desc$NOM_GRUPO
                               , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                               , NOM_PROD     = desc$NOM_PROD
                               , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                               , N.DAYS       = nrow(df.a)
                               , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                               , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                               , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                               )
    }
    
  }
}; rm(loja); rm(plu); rm(df.a); rm(desc)
