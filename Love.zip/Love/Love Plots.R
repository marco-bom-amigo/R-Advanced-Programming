#################
## Bibliotecas ##
#################
library(lubridate)
library(forecast)
library(dummies)
library(scales)
#################

names(df.measures)
df.measures$S.DAYS
df.measures$N.TRANS

loja <- unique(df.measures$COD_LOJA)[1]
color <- 2
d <- density(df.measures[df.measures$COD_LOJA == loja,]$S.DAYS)
plot( d
      , main = ""
      , yaxt = 'n'
      , xaxt = 'n'
      , ylab = ''
      , xlab = 'Dias com Venda'
      , frame= F
)
polygon(d, col = alpha(color, .5), border = color)

loja <- unique(df.measures$COD_LOJA)[2]
color <- color + 1
d <- density(df.measures[df.measures$COD_LOJA == loja,]$S.DAYS)
polygon(d, col = alpha(color, .5), border = color)

stats <- boxplot(df.measures$S.DAYS, plot = F)$stats
axis(1, at = stats, labels = stats)
abline(v = stats, col = 'darkgray', lty = 2)
