#################
## Bibliotecas ##
#################
library(lubridate)
library(forecast)
library(dummies)
library(scales)
#################

PrevDem <- read.csv("~/Guia de Produção/Love/data/PrevDem.csv", stringsAsFactors = F)
PrevDem$DAT_DIA_CALEND <- as.Date(PrevDem$DAT_DIA_CALEND)

Plan11 <- merge( df.prev[,c("COD_LOJA", "plu", "pred.d1")]
               , PrevDem[PrevDem$DAT_DIA_CALEND == '2019-07-11',]
               , by.x = c("COD_LOJA" , "plu")
               , by.y = c("COD_LOCAL", "COD_PLU")
               )

Plan11 <- merge( Plan11
               , df.measures[,1:8]
               , all.x = T
               )

Plan11 <- Plan11[,c(3,1,2,11,10,9,8,7,6,4,5)]

Plan11$`Guia de Producao`         <- gsub("[.]", ",",Plan11$`Guia de Producao`)
Plan11$QTD_VENDA_PREVISAO_SISTEMA <- gsub("[.]", ",",Plan11$QTD_VENDA_PREVISAO_SISTEMA)


loja <- unique(df.measures$COD_LOJA)[1]
color <- 2
d <- density(df.measures[df.measures$COD_LOJA == loja,]$S.DAYS)
plot( d
      , main = ""
      , yaxt = 'n'
      , xaxt = 'n'
      , ylab = ''
      , xlab = 'Dias com Venda'
      , frame= F
)
polygon(d, col = alpha(color, .5), border = color)

loja <- unique(df.measures$COD_LOJA)[2]
color <- color + 1
d <- density(df.measures[df.measures$COD_LOJA == loja,]$S.DAYS)
polygon(d, col = alpha(color, .5), border = color)

stats <- boxplot(df.measures$S.DAYS, plot = F)$stats
axis(1, at = stats, labels = stats)
abline(v = stats, col = 'darkgray', lty = 2)
