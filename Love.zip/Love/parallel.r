library(parallel)
library(MASS)

numCores <- detectCores()

starts <- rep(100, 400)
fx <- function(nstart) kmeans(Boston, 4, nstart=nstart)

system.time(
  results <- mclapply(starts, fx, mc.cores = numCores)
)

ps <- function(x) {paste(x, x)}
mclapply(ps, head(df[,c("codloja")],20), mc.cores = numCores)

####
####

for (i in 1:3) {
  print(sqrt(i))
}

library(foreach)
foreach (i=1:3) %do% {
  sqrt(i)
}

library(foreach)
library(doParallel)
registerDoParallel(numCores)  # use multicore, set to the number of our cores

foreach (i=1:3) %dopar% {
  sqrt(i)
}

foreach (i = unique(df[,c("codloja")]), .combine=rbind) %dopar% {
  print(i)
  foreach (j = unique(df[df$codloja == i,c("plu")]), .combine=rbind) %dopar% {
     print(paste(j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20, j^20))
  } -> t
  if (!exists('df.p')) {
    df.p <- data.frame(loja = i, plu = t)
  } else {
    df.p <- rbind(df.p, data.frame(loja = i, plu = t))
  }
} -> df.p

rm(df.p)

