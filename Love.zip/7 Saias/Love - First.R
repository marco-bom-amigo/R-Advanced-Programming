#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
library(stringr)
#################

for (loja in unique(df$codloja)) {
  for (plu in unique(df[df$codloja == loja,]$plu)) {

    #################
    ## Current Row ##
    #################
    cat(paste('\n', loja, ' | ', plu, sep = ''))
    #################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a <- df[df$codloja == loja & df$plu == plu, c("datvenda", "QTD_VENDIDA_PROD")]
    df.a <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    #########################

    ##################
    ## All Dates <3 ##
    ##################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , max(df.a$datvenda)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ##################
    
    ###############
    ## Empty ='( ##
    ###############
    df.a$QTD_VENDIDA_PROD[is.na(df.a$QTD_VENDIDA_PROD)] <- 0
    ###############

    ###########
    ## Pre�o ##
    ###########
    preco <- df[df$codloja == loja & df$plu == plu,]
    preco <- preco[order(preco$datvenda),]
    preco <- preco[!duplicated(preco$preco),c("datvenda", "preco")]
    df.a <- merge( df.a
                 , preco
                 , all.x = T
                 ); rm(preco)
    
    l.preco <- df.a[1,]$preco
    if (nrow(df.a) > 1) {
      for (i in 2:nrow(df.a)) {
        if (is.na(df.a[i,]$preco)) {
          df.a[i,]$preco <- l.preco
        } else {
          l.preco <- df.a[i,]$preco
        }
      }; rm(l.preco); rm(i)
    }
    ###########    

    ##########################
    ## Auto Regressive...?! ##
    ##########################
    if (nrow(df.a) > 7) {
      df.m.7 <- df.a[1:(nrow(df.a)-7),]$QTD_VENDIDA_PROD
      df.m.6 <- df.a[1:(nrow(df.a)-6),]$QTD_VENDIDA_PROD; df.m.6 <- df.m.6[2:length(df.m.6)]
      df.m.5 <- df.a[1:(nrow(df.a)-5),]$QTD_VENDIDA_PROD; df.m.5 <- df.m.5[3:length(df.m.5)]
      df.m.4 <- df.a[1:(nrow(df.a)-4),]$QTD_VENDIDA_PROD; df.m.4 <- df.m.4[4:length(df.m.4)]
      df.m.3 <- df.a[1:(nrow(df.a)-3),]$QTD_VENDIDA_PROD; df.m.3 <- df.m.3[5:length(df.m.3)]
      df.m.2 <- df.a[1:(nrow(df.a)-2),]$QTD_VENDIDA_PROD; df.m.2 <- df.m.2[6:length(df.m.2)]
      df.m.1 <- df.a[1:(nrow(df.a)-1),]$QTD_VENDIDA_PROD; df.m.1 <- df.m.1[7:length(df.m.1)]
      
      df.a <- df.a[8:nrow(df.a),]
      df.a$m.1 <- df.m.1
      df.a$m.2 <- df.m.2
      df.a$m.3 <- df.m.3
      df.a$m.4 <- df.m.4
      df.a$m.5 <- df.m.5
      df.a$m.6 <- df.m.6
      df.a$m.7 <- df.m.7
      
      rm(list = c('df.m.7','df.m.6','df.m.5','df.m.4','df.m.3','df.m.2','df.m.1'))
    }
    ##########################

    ###################
    ## Date Features ##
    ###################
    df.a$year  <- year(df.a$datvenda)
    df.a$month <- month(df.a$datvenda)
    df.a$wday  <- as.POSIXlt(df.a$datvenda)$wday
    df.a$day   <- day(df.a$datvenda)
    ###################
    
    ##################
    ## N� da Semana ##
    ##################
    week <- 0
    df.a$week <- 0
    for (i in 1:nrow(df.a)) {
      df.a[i,]$week <- week
      if (df.a[i,]$wday == 6) {
        week <- week + 1
      }
    }; rm(week); rm(i)
    ##################
    
    ################
    ## Dummies <3 ##
    ################
    w.o.label <- c("wday)0", "wday)1", "wday)2", "wday)3", "wday)4", "wday)5", "wday)6")
    w.label <- c('dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab')
    dm <- as.data.frame(dummy(df.a$wday))
    names(dm) <- w.label[match(names(dm), w.o.label)]
    df.a <- cbind(df.a, dm)

    m.o.label <- c("month)1", "month)2", "month)3", "month)4", "month)5", "month)6", "month)7", "month)8", "month)9", "month)10", "month)11", "month)12")
    m.label <- c('Janeiro','Fevereiro','Mar�o','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro')   
    dm <- as.data.frame(dummy(df.a$month))
    names(dm) <- m.label[match(names(dm), m.o.label)]
    df.a <- cbind(df.a, dm)
    rm(list = c('dm', 'w.o.label', 'w.label', 'm.o.label', 'm.label'))
    ################
    
    df.a$HASH <- as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))
    f <- sort(unique(as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))))
    
    MAPE <- Inf
    for (h in f) {
      df.h <- df.a[df.a$HASH > h,]
      df.h <- df.h[,-length(df.h)]

      ##############
      ## Outliers ##
      ##############
      stats <- boxplot(df.h$QTD_VENDIDA_PROD[df.h$QTD_VENDIDA_PROD > 0], plot = F)$stats
      row.names(df.h) <- NULL
      df.out <- df.h[df.h$QTD_VENDIDA_PROD > stats[5],]
      if (nrow(df.out) > 0) {
        for (i in 1:nrow(df.out)) {
          mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$wday  == df.out[i,]$wday & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)
          if (is.na(mn)) {mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)}
          if (!is.na(mn)) {
            df.h[as.numeric(row.names(df.out[i,])),]$QTD_VENDIDA_PROD <- mn
          }
        }; rm(i); rm(mn)
      }; rm(df.out)
      ###################

      ##############################
      ## Sazonalidade e Tend�ncia ##
      ##############################
      if (nrow(df.h) > 14) {
        stl  <- as.data.frame(stl(ts(df.h$QTD_VENDIDA_PROD, frequency = 7), s.window = 7)$time.series)
        df.h <- cbind(df.h, stl[,c('seasonal', 'trend')])
        rm(stl)
      }
      ##############################

      if (nrow(df.h) > 7) {
        df.train <- df.h[1:(nrow(df.h)-7),]
        df.test  <- df.h[(nrow(df.h)-6):nrow(df.h),]
        mod <- lm(QTD_VENDIDA_PROD ~ ., data = df.train)
        coef <- as.data.frame(coef(summary(mod)))
      }
      while (!is.null(dim(df.h)) & !sum(is.na(coef[-1,]$`Pr(>|t|)`)) == length(coef[-1,]$`Pr(>|t|)`)) {
        for (l in 1:4) {
          if (nrow(df.h) > 7) {
            df.train <- df.h[1:(nrow(df.h)-7),]
            df.test  <- df.h[(nrow(df.h)-6):nrow(df.h),]
          }
          if (l > 2) {
              df.train$month <- NULL
              df.train$wday  <- NULL
              df.test$month  <- NULL
              df.test$wday   <- NULL
            }
          if (l %in% c(2,3)) {
            df.train$trend    <- NULL
            df.train$seasonal <- NULL
            df.test$trend     <- NULL
            df.test$seasonal  <- NULL
          }
          mod <- lm(QTD_VENDIDA_PROD ~ ., data = df.train)
          pred <- predict(mod, df.test); real <- df.test$QTD_VENDIDA_PROD; indx <- real == 0; pred[pred < 0] <- 0; pred[indx] <- pred[indx] + 1; real[indx] <- real[indx] + 1
          if (round(mean((abs(real - pred)/real)) * 100, 2) < MAPE) {
            MAPE <- round(mean((abs(real - pred)/real)) * 100, 2)
          }
        }
        coef <- as.data.frame(coef(summary(mod)))
        df.h <- df.h[,c(row.names(coef(summary(mod)))[-1], 'QTD_VENDIDA_PROD')]
        if (!sum(is.na(coef[-1,]$`Pr(>|t|)`)) == length(coef[-1,]$`Pr(>|t|)`)) {
          df.h <- df.h[,-(which.max(coef[-1,]$`Pr(>|t|)`))]
        }
      }
    }
    cat(paste('\n', MAPE, '\n', sep = ''))
    if (exists('result')) {
      result <- rbind(result, data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE))
    } else {
      result <- data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE)
    }
  }
}
write.csv(result, 'data/result_mp.csv', row.names = F)


names(result)[3] <- 'MAPE.MLR'
names(df.wo)[3] <- 'MAPE.MLR.wo'

df.full <- merge(df.measures, result, all.x = T)
df.full <- merge(df.full, df.wo, all.x = T)
names(df.full)[14:15]

df.full$b.acc <- 0
for (i in i:nrow(df.full)) {
  df.full[i,]$b.acc <- df.full[i,which.min(df.full[i,14:15])+13]
}; rm(i)

View(df.full[,c("COD_LOJA", "plu", "MAPE.MLR", "MAPE.MLR.wo", "b.acc")])

