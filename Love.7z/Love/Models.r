########################
## Load Models | MAPE ##
########################
files <- list.files('models/MAPE/m1a')
m.m1a <- readRDS(paste('models/MAPE/m1a/', files[1],sep = ''))
for (i in files[2:length(files)]) {
  m.m1a <- c(m.m1a,readRDS(paste('models/MAPE/m1a/',i,sep = '')))
}

files <- list.files('models/MAPE/m1b')
m.m1b <- readRDS(paste('models/MAPE/m1b/', files[1],sep = ''))
for (i in files[2:length(files)]) {
  m.m1b <- c(m.m1b,readRDS(paste('models/MAPE/m1b/',i,sep = '')))
}

m.m2a <- readRDS('models/MAPE/m2a/m.1.rds')
m.m2b <- readRDS('models/MAPE/m2b/m.1.rds')

rm(i); rm(files)
########################

########################
## Load Models | RMSE ##
########################
files <- list.files('models/RMSE/m1a')
r.m1a <- readRDS(paste('models/RMSE/m1a/', files[1],sep = ''))
for (i in files[2:length(files)]) {
  r.m1a <- c(r.m1a,readRDS(paste('models/RMSE/m1a/',i,sep = '')))
}

files <- list.files('models/RMSE/m1b')
r.m1b <- readRDS(paste('models/RMSE/m1b/', files[1],sep = ''))
for (i in files[2:length(files)]) {
  r.m1b <- c(r.m1b,readRDS(paste('models/RMSE/m1b/',i,sep = '')))
}

r.m2a <- readRDS('models/RMSE/m2a/m.1.rds')
r.m2b <- readRDS('models/RMSE/m2b/m.1.rds')

rm(i); rm(files)
########################

################
## Best Model ##
################
md <- list()
for (i in 1:nrow(df.measures)) {

  id <- paste(df.measures[i,]$COD_LOJA,df.measures[i,]$plu,sep='.')

  p.MAPE <- Inf
  b.MAPE <- NA
  l.MAPE <- ''
  if (!is.null(m.m1a[[id]])) {
    if (m.m1a[[id]]$MAPE < p.MAPE) {
      p.MAPE <- m.m1a[[id]]$MAPE
      b.MAPE <- m.m1a[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 1 | a) [MAPE]'
    }
  }
  if (!is.null(m.m1b[[id]])) {
    if (m.m1b[[id]]$MAPE < p.MAPE) {
      p.MAPE <- m.m1b[[id]]$MAPE
      b.MAPE <- m.m1b[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 1 | b) [MAPE]'
    }
  }
  if (!is.null(m.m2a[[id]])) {
    if (m.m2a[[id]]$MAPE < p.MAPE) {
      p.MAPE <- m.m2a[[id]]$MAPE
      b.MAPE <- m.m2a[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 2 | a) [MAPE]'
    }
  }
  if (!is.null(m.m2b[[id]])) {
    if (m.m2b[[id]]$MAPE < p.MAPE) {
      p.MAPE <- m.m2b[[id]]$MAPE
      b.MAPE <- m.m2b[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 2 | b) [MAPE]'
    }
  }
  if (!is.null(r.m1a[[id]])) {
    if (r.m1a[[id]]$MAPE < p.MAPE) {
      p.MAPE <- r.m1a[[id]]$MAPE
      b.MAPE <- r.m1a[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 1 | a) [RMSE]'
    }
  }
  if (!is.null(r.m1b[[id]])) {
    if (r.m1b[[id]]$MAPE < p.MAPE) {
      p.MAPE <- r.m1b[[id]]$MAPE
      b.MAPE <- r.m1b[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 1 | b) [RMSE]'
    }
  }
  if (!is.null(r.m2a[[id]])) {
    if (r.m2a[[id]]$MAPE < p.MAPE) {
      p.MAPE <- r.m2a[[id]]$MAPE
      b.MAPE <- r.m2a[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 2 | a) [RMSE]'
    }
  }
  if (!is.null(r.m2b[[id]])) {
    if (r.m2b[[id]]$MAPE < p.MAPE) {
      p.MAPE <- r.m2b[[id]]$MAPE
      b.MAPE <- r.m2b[[id]]$model
      l.MAPE <- 'Predicao Guia (Mod 2 | b) [RMSE]'
    }
  }

  p.RMSE <- Inf
  b.RMSE <- NA
  l.RMSE <- ''
  if (!is.null(m.m1a[[id]])) {
    if (m.m1a[[id]]$RMSE < p.RMSE) {
      p.RMSE <- m.m1a[[id]]$RMSE
      b.RMSE <- m.m1a[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 1 | a) [MAPE]'
    }
  }
  if (!is.null(m.m1b[[id]])) {
    if (m.m1b[[id]]$RMSE < p.RMSE) {
      p.RMSE <- m.m1b[[id]]$RMSE
      b.RMSE <- m.m1b[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 1 | b) [MAPE]'
    }
  }
  if (!is.null(m.m2a[[id]])) {
    if (m.m2a[[id]]$RMSE < p.RMSE) {
      p.RMSE <- m.m2a[[id]]$RMSE
      b.RMSE <- m.m2a[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 2 | a) [MAPE]'
    }
  }
  if (!is.null(m.m2b[[id]])) {
    if (m.m2b[[id]]$RMSE < p.RMSE) {
      p.RMSE <- m.m2b[[id]]$RMSE
      b.RMSE <- m.m2b[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 2 | b) [MAPE]'
    }
  }
  if (!is.null(r.m1a[[id]])) {
    if (r.m1a[[id]]$RMSE < p.RMSE) {
      p.RMSE <- r.m1a[[id]]$RMSE
      b.RMSE <- r.m1a[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 1 | a) [RMSE]'
    }
  }
  if (!is.null(r.m1b[[id]])) {
    if (r.m1b[[id]]$RMSE < p.RMSE) {
      p.RMSE <- r.m1b[[id]]$RMSE
      b.RMSE <- r.m1b[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 1 | b) [RMSE]'
    }
  }
  if (!is.null(r.m2a[[id]])) {
    if (r.m2a[[id]]$RMSE < p.RMSE) {
      p.RMSE <- r.m2a[[id]]$RMSE
      b.RMSE <- r.m2a[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 2 | a) [RMSE]'
    }
  }
  if (!is.null(r.m2b[[id]])) {
    if (r.m2b[[id]]$RMSE < p.RMSE) {
      p.RMSE <- r.m2b[[id]]$RMSE
      b.RMSE <- r.m2b[[id]]$model
      l.RMSE <- 'Predicao Guia (Mod 2 | b) [RMSE]'
    }
  }
  
  md[[id]] <- list( m.m1a  = m.m1a[[id]][c(1,4,5)]
                  , m.m1b  = m.m1b[[id]][c(1,4,5)]
                  , m.m2a  = m.m2a[[id]][c(1,4,5)]
                  , m.m2b  = m.m2b[[id]][c(1,4,5)]
                  , r.m1a  = r.m1a[[id]][c(1,4,5)]
                  , r.m1b  = r.m1b[[id]][c(1,4,5)]
                  , r.m2a  = r.m2a[[id]][c(1,4,5)]
                  , r.m2b  = r.m2b[[id]][c(1,4,5)]
                  , b.MAPE = b.MAPE
                  , b.RMSE = b.RMSE
                  , l.MAPE = l.MAPE
                  , l.RMSE = l.RMSE
  )
}; rm(list = c('i', 'id', 'p.MAPE', 'p.RMSE', 'b.MAPE', 'b.RMSE'))
################

saveRDS(md, "models/md.rds")


