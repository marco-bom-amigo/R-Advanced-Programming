###############
## Read data ##
###############

# m1a
files <- list.files('results/m1a')
m1a   <- read.csv(paste('results/m1a/', files[1], sep = ''), stringsAsFactors = F)
for (file in files[2:18]) {
  m1a <- rbind(m1a, read.csv(paste('results/m1a/', file, sep = ''), stringsAsFactors = F))
}; rm(file); rm(files)

# m1b
files <- list.files('results/m1b')
m1b <- read.csv(paste('results/m1b/', files[1], sep = ''), stringsAsFactors = F)
for (file in files) {
  m1b <- rbind(m1b, read.csv(paste('results/m1b/', file, sep = ''), stringsAsFactors = F))
}; rm(file); rm(files)

# m2a
m2a <- read.csv('results/m2a/r.csv', stringsAsFactors = F)

# m2b
m2b <- read.csv('results/m2b/r.csv', stringsAsFactors = F)
###############

########
## 26 ##
########
r26 <- merge(df.measures, m1a[c(1,2,7)]); names(r26)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r26 <- merge(r26, m1b[c(1,2, 7)]); names(r26)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r26 <- merge(r26, m2a[c(1,2, 7)]); names(r26)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r26 <- merge(r26, m2b[c(1,2, 7)]); names(r26)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r26 <- merge(r26, m1a[c(1,2,14)]); names(r26)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r26 <- merge(r26, m1b[c(1,2,14)]); names(r26)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r26 <- merge(r26, m2a[c(1,2,14)]); names(r26)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r26 <- merge(r26, m2b[c(1,2,14)]); names(r26)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r26$date <- as.Date('2019-08-04') + days(1)
r26 <- r26[,c(17,1:16)]
r26 <- merge(r26, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r26)[18] <- 'Demanda'
r26 <- merge(r26, real, by.x = c("COD_LOJA", "plu", "date"), by.y = c("codloja", "plu", "datvenda"), all.x = T)
names(r26)[19] <- 'Real'

r26$Demanda[is.na(r26$Demanda)] <- 0
r26$Real[is.na(r26$Real)] <- 0
########

########
## 27 ##
########
r27 <- merge(df.measures, m1a[c(1,2,6)]); names(r27)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r27 <- merge(r27, m1b[c(1,2,6)]); names(r27)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r27 <- merge(r27, m2a[c(1,2,6)]); names(r27)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r27 <- merge(r27, m2b[c(1,2,6)]); names(r27)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r27 <- merge(r27, m1a[c(1,2,13)]); names(r27)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r27 <- merge(r27, m1b[c(1,2,13)]); names(r27)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r27 <- merge(r27, m2a[c(1,2,13)]); names(r27)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r27 <- merge(r27, m2b[c(1,2,13)]); names(r27)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r27$date <- as.Date('2019-08-04') + days(2)
r27 <- r27[,c(17,1:16)]
r27 <- merge(r27, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r27)[18] <- 'Demanda'
r27 <- merge(r27, real, by.x = c("COD_LOJA", "plu", "date"), by.y = c("codloja", "plu", "datvenda"), all.x = T)
names(r27)[19] <- 'Real'

r27$Demanda[is.na(r27$Demanda)] <- 0
r27$Real[is.na(r27$Real)] <- 0
########

########
## 28 ##
########
r28 <- merge(df.measures, m1a[c(1,2,7)]); names(r28)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r28 <- merge(r28, m1b[c(1,2,7)]); names(r28)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r28 <- merge(r28, m2a[c(1,2,7)]); names(r28)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r28 <- merge(r28, m2b[c(1,2,7)]); names(r28)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r28 <- merge(r28, m1a[c(1,2,14)]); names(r28)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r28 <- merge(r28, m1b[c(1,2,14)]); names(r28)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r28 <- merge(r28, m2a[c(1,2,14)]); names(r28)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r28 <- merge(r28, m2b[c(1,2,14)]); names(r28)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r28$date <- as.Date('2019-08-04') + days(3)
r28 <- r28[,c(17,1:16)]
r28 <- merge(r28, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r28)[18] <- 'Demanda'
r28$Demanda[is.na(r28$Demanda)] <- 0
########

########
## 29 ##
########
r29 <- merge(df.measures, m1a[c(1,2,8)]); names(r29)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r29 <- merge(r29, m1b[c(1,2,8)]); names(r29)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r29 <- merge(r29, m2a[c(1,2,8)]); names(r29)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r29 <- merge(r29, m2b[c(1,2,8)]); names(r29)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r29 <- merge(r29, m1a[c(1,2,15)]); names(r29)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r29 <- merge(r29, m1b[c(1,2,15)]); names(r29)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r29 <- merge(r29, m2a[c(1,2,15)]); names(r29)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r29 <- merge(r29, m2b[c(1,2,15)]); names(r29)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r29$date <- as.Date('2019-08-04') + days(4)
r29 <- r29[,c(17,1:16)]
r29 <- merge(r29, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r29)[18] <- 'Demanda'
r29$Demanda[is.na(r29$Demanda)] <- 0
########

########
## 30 ##
########
r30 <- merge(df.measures, m1a[c(1,2,9)]); names(r30)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r30 <- merge(r30, m1b[c(1,2,9)]); names(r30)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r30 <- merge(r30, m2a[c(1,2,9)]); names(r30)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r30 <- merge(r30, m2b[c(1,2,9)]); names(r30)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r30 <- merge(r30, m1a[c(1,2,16)]); names(r30)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r30 <- merge(r30, m1b[c(1,2,16)]); names(r30)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r30 <- merge(r30, m2a[c(1,2,16)]); names(r30)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r30 <- merge(r30, m2b[c(1,2,16)]); names(r30)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r30$date <- as.Date('2019-08-04') + days(5)
r30 <- r30[,c(17,1:16)]
r30 <- merge(r30, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r30)[18] <- 'Demanda'
r30$Demanda[is.na(r30$Demanda)] <- 0
########

########
## 31 ##
########
r31 <- merge(df.measures, m1a[c(1,2,10)]); names(r31)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r31 <- merge(r31, m1b[c(1,2,10)]); names(r31)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r31 <- merge(r31, m2a[c(1,2,10)]); names(r31)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r31 <- merge(r31, m2b[c(1,2,10)]); names(r31)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r31 <- merge(r31, m1a[c(1,2,17)]); names(r31)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r31 <- merge(r31, m1b[c(1,2,17)]); names(r31)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r31 <- merge(r31, m2a[c(1,2,17)]); names(r31)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r31 <- merge(r31, m2b[c(1,2,17)]); names(r31)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r31$date <- as.Date('2019-08-04') + days(6)
r31 <- r31[,c(17,1:16)]
r31 <- merge(r31, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r31)[18] <- 'Demanda'
r31$Demanda[is.na(r31$Demanda)] <- 0
########

########
## 01 ##
########
r01 <- merge(df.measures, m1a[c(1,2,11)]); names(r01)[9] <- 'Predicao Guia (Mod 1 | a) [MAPE]'
r01 <- merge(r01, m1b[c(1,2,11)]); names(r01)[10] <- 'Predicao Guia (Mod 1 | b) [MAPE]'
r01 <- merge(r01, m2a[c(1,2,11)]); names(r01)[11] <- 'Predicao Guia (Mod 2 | a) [MAPE]'
r01 <- merge(r01, m2b[c(1,2,11)]); names(r01)[12] <- 'Predicao Guia (Mod 2 | b) [MAPE]'
r01 <- merge(r01, m1a[c(1,2,18)]); names(r01)[13] <- 'Predicao Guia (Mod 1 | a) [RMSE]'
r01 <- merge(r01, m1b[c(1,2,18)]); names(r01)[14] <- 'Predicao Guia (Mod 1 | b) [RMSE]'
r01 <- merge(r01, m2a[c(1,2,18)]); names(r01)[15] <- 'Predicao Guia (Mod 2 | a) [RMSE]'
r01 <- merge(r01, m2b[c(1,2,18)]); names(r01)[16] <- 'Predicao Guia (Mod 2 | b) [RMSE]'
r01$date <- as.Date('2019-08-04') + days(7)
r01 <- r01[,c(17,1:16)]
r01 <- merge(r01, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r01)[18] <- 'Demanda'
r01$Demanda[is.na(r01$Demanda)] <- 0
########

###########
## ERROR ##
###########
names(m1a)[c(3,5)] <- c("Predicao Guia (Mod 1 | a) [MAPE]", "Predicao Guia (Mod 1 | a) [RMSE]")
names(m1b)[c(3,5)] <- c("Predicao Guia (Mod 1 | b) [MAPE]", "Predicao Guia (Mod 1 | b) [RMSE]")
names(m2a)[c(3,5)] <- c("Predicao Guia (Mod 2 | a) [MAPE]", "Predicao Guia (Mod 2 | a) [RMSE]")
names(m2b)[c(3,5)] <- c("Predicao Guia (Mod 2 | b) [MAPE]", "Predicao Guia (Mod 2 | b) [RMSE]")

ERROR.M <- merge(df.measures[,c(1:2)], m1a[,c(1:3)], all.x = T)
ERROR.M <- merge(ERROR.M, m1b[,c(1:3)], all.x = T)
ERROR.M <- merge(ERROR.M, m2a[,c(1:3)], all.x = T)
ERROR.M <- merge(ERROR.M, m2b[,c(1:3)], all.x = T)

ERROR.R <- merge(df.measures[,c(1:2)], m1a[,c(1,2,5)], all.x = T)
ERROR.R <- merge(ERROR.R, m1b[,c(1,2,5)], all.x = T)
ERROR.R <- merge(ERROR.R, m2a[,c(1,2,5)], all.x = T)
ERROR.R <- merge(ERROR.R, m2b[,c(1,2,5)], all.x = T)
###########

################
## Best ERROR ##
################
r26$Best.ERROR.MAPE <- 0
r27$Best.ERROR.MAPE <- 0
r28$Best.ERROR.MAPE <- 0
r29$Best.ERROR.MAPE <- 0
r30$Best.ERROR.MAPE <- 0
r31$Best.ERROR.MAPE <- 0
r01$Best.ERROR.MAPE <- 0

r26$Best.MODEL.MAPE <- ''
r27$Best.MODEL.MAPE <- ''
r28$Best.MODEL.MAPE <- ''
r29$Best.MODEL.MAPE <- ''
r30$Best.MODEL.MAPE <- ''
r31$Best.MODEL.MAPE <- ''
r01$Best.MODEL.MAPE <- ''

for (i in 1:nrow(ERROR.M)) {
  if (length(ERROR.M[i,names(which.min(ERROR.M[i,c(3:6)]))]) > 0) {
    
    tryCatch({
      r26[ERROR.M[i,]$COD_LOJA == r26$COD_LOJA & ERROR.M[i,]$plu == r26$plu,]$Best.ERROR.MAPE <- r26[ERROR.M[i,]$COD_LOJA == r26$COD_LOJA & ERROR.M[i,]$plu == r26$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r26[ERROR.M[i,]$COD_LOJA == r26$COD_LOJA & ERROR.M[i,]$plu == r26$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
  
      r27[ERROR.M[i,]$COD_LOJA == r27$COD_LOJA & ERROR.M[i,]$plu == r27$plu,]$Best.ERROR.MAPE <- r27[ERROR.M[i,]$COD_LOJA == r27$COD_LOJA & ERROR.M[i,]$plu == r27$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r27[ERROR.M[i,]$COD_LOJA == r27$COD_LOJA & ERROR.M[i,]$plu == r27$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
      
      r28[ERROR.M[i,]$COD_LOJA == r28$COD_LOJA & ERROR.M[i,]$plu == r28$plu,]$Best.ERROR.MAPE <- r28[ERROR.M[i,]$COD_LOJA == r28$COD_LOJA & ERROR.M[i,]$plu == r28$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r28[ERROR.M[i,]$COD_LOJA == r28$COD_LOJA & ERROR.M[i,]$plu == r28$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
  
      r29[ERROR.M[i,]$COD_LOJA == r29$COD_LOJA & ERROR.M[i,]$plu == r29$plu,]$Best.ERROR.MAPE <- r29[ERROR.M[i,]$COD_LOJA == r29$COD_LOJA & ERROR.M[i,]$plu == r29$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r29[ERROR.M[i,]$COD_LOJA == r29$COD_LOJA & ERROR.M[i,]$plu == r29$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
      
      r30[ERROR.M[i,]$COD_LOJA == r30$COD_LOJA & ERROR.M[i,]$plu == r30$plu,]$Best.ERROR.MAPE <- r30[ERROR.M[i,]$COD_LOJA == r30$COD_LOJA & ERROR.M[i,]$plu == r30$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r30[ERROR.M[i,]$COD_LOJA == r30$COD_LOJA & ERROR.M[i,]$plu == r30$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
      
      r31[ERROR.M[i,]$COD_LOJA == r31$COD_LOJA & ERROR.M[i,]$plu == r31$plu,]$Best.ERROR.MAPE <- r31[ERROR.M[i,]$COD_LOJA == r31$COD_LOJA & ERROR.M[i,]$plu == r31$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r31[ERROR.M[i,]$COD_LOJA == r31$COD_LOJA & ERROR.M[i,]$plu == r31$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
      
      r01[ERROR.M[i,]$COD_LOJA == r01$COD_LOJA & ERROR.M[i,]$plu == r01$plu,]$Best.ERROR.MAPE <- r01[ERROR.M[i,]$COD_LOJA == r01$COD_LOJA & ERROR.M[i,]$plu == r01$plu,names(which.min(ERROR.M[i,c(3:6)]))]
      r01[ERROR.M[i,]$COD_LOJA == r01$COD_LOJA & ERROR.M[i,]$plu == r01$plu,]$Best.MODEL.MAPE <- names(which.min(ERROR.M[i,c(3:6)]))
    }, error = function(cond) {})
  }
}

r26$Best.ERROR.RMSE <- 0
r27$Best.ERROR.RMSE <- 0
r28$Best.ERROR.RMSE <- 0
r29$Best.ERROR.RMSE <- 0
r30$Best.ERROR.RMSE <- 0
r31$Best.ERROR.RMSE <- 0
r01$Best.ERROR.RMSE <- 0

r26$Best.MODEL.RMSE <- ''
r27$Best.MODEL.RMSE <- ''
r28$Best.MODEL.RMSE <- ''
r29$Best.MODEL.RMSE <- ''
r30$Best.MODEL.RMSE <- ''
r31$Best.MODEL.RMSE <- ''
r01$Best.MODEL.RMSE <- ''

for (i in 1:nrow(ERROR.R)) {
  if (length(ERROR.R[i,names(which.min(ERROR.R[i,c(3:6)]))]) > 0) {
    
    tryCatch({
      r26[ERROR.R[i,]$COD_LOJA == r26$COD_LOJA & ERROR.R[i,]$plu == r26$plu,]$Best.ERROR.RMSE <- r26[ERROR.R[i,]$COD_LOJA == r26$COD_LOJA & ERROR.R[i,]$plu == r26$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r26[ERROR.R[i,]$COD_LOJA == r26$COD_LOJA & ERROR.R[i,]$plu == r26$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r27[ERROR.R[i,]$COD_LOJA == r27$COD_LOJA & ERROR.R[i,]$plu == r27$plu,]$Best.ERROR.RMSE <- r27[ERROR.R[i,]$COD_LOJA == r27$COD_LOJA & ERROR.R[i,]$plu == r27$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r27[ERROR.R[i,]$COD_LOJA == r27$COD_LOJA & ERROR.R[i,]$plu == r27$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r28[ERROR.R[i,]$COD_LOJA == r28$COD_LOJA & ERROR.R[i,]$plu == r28$plu,]$Best.ERROR.RMSE <- r28[ERROR.R[i,]$COD_LOJA == r28$COD_LOJA & ERROR.M[i,]$plu == r28$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r28[ERROR.R[i,]$COD_LOJA == r28$COD_LOJA & ERROR.R[i,]$plu == r28$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r29[ERROR.R[i,]$COD_LOJA == r29$COD_LOJA & ERROR.R[i,]$plu == r29$plu,]$Best.ERROR.RMSE <- r29[ERROR.R[i,]$COD_LOJA == r29$COD_LOJA & ERROR.R[i,]$plu == r29$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r29[ERROR.R[i,]$COD_LOJA == r29$COD_LOJA & ERROR.R[i,]$plu == r29$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r30[ERROR.R[i,]$COD_LOJA == r30$COD_LOJA & ERROR.R[i,]$plu == r30$plu,]$Best.ERROR.RMSE <- r30[ERROR.R[i,]$COD_LOJA == r30$COD_LOJA & ERROR.R[i,]$plu == r30$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r30[ERROR.R[i,]$COD_LOJA == r30$COD_LOJA & ERROR.R[i,]$plu == r30$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r31[ERROR.R[i,]$COD_LOJA == r31$COD_LOJA & ERROR.R[i,]$plu == r31$plu,]$Best.ERROR.RMSE <- r31[ERROR.R[i,]$COD_LOJA == r31$COD_LOJA & ERROR.R[i,]$plu == r31$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r31[ERROR.R[i,]$COD_LOJA == r31$COD_LOJA & ERROR.R[i,]$plu == r31$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
      
      r01[ERROR.R[i,]$COD_LOJA == r01$COD_LOJA & ERROR.R[i,]$plu == r01$plu,]$Best.ERROR.RMSE <- r01[ERROR.R[i,]$COD_LOJA == r01$COD_LOJA & ERROR.R[i,]$plu == r01$plu,names(which.min(ERROR.R[i,c(3:6)]))]
      r01[ERROR.R[i,]$COD_LOJA == r01$COD_LOJA & ERROR.R[i,]$plu == r01$plu,]$Best.MODEL.RMSE <- names(which.min(ERROR.R[i,c(3:6)]))
    }, error = function(cond) {})
  }
}; rm(i)
################

############
## Format ##
############
r26$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 1 | a) [MAPE]`)
r26$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 1 | b) [MAPE]`)
r26$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 2 | a) [MAPE]`)
r26$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 2 | b) [MAPE]`)
r26$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 1 | a) [RMSE]`)
r26$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 1 | b) [RMSE]`)
r26$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 2 | a) [RMSE]`)
r26$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (Mod 2 | b) [RMSE]`)
r26$Best.ERROR.MAPE <- gsub("[.]", ",",r26$Best.ERROR.MAPE)
r26$Best.ERROR.RMSE <- gsub("[.]", ",",r26$Best.ERROR.RMSE)
r26$Demanda <- gsub("[.]", ",",r26$Demanda)
r26$Real <- gsub("[.]", ",",r26$Real)

r27$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 1 | a) [MAPE]`)
r27$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 1 | b) [MAPE]`)
r27$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 2 | a) [MAPE]`)
r27$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 2 | b) [MAPE]`)
r27$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 1 | a) [RMSE]`)
r27$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 1 | b) [RMSE]`)
r27$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 2 | a) [RMSE]`)
r27$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (Mod 2 | b) [RMSE]`)
r27$Demanda <- gsub("[.]", ",",r27$Demanda)
r27$Best.ERROR.MAPE <- gsub("[.]", ",",r27$Best.ERROR.MAPE)
r27$Best.ERROR.RMSE <- gsub("[.]", ",",r27$Best.ERROR.RMSE)
r27$Real <- gsub("[.]", ",",r27$Real)

r28$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 1 | a) [MAPE]`)
r28$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 1 | b) [MAPE]`)
r28$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 2 | a) [MAPE]`)
r28$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 2 | b) [MAPE]`)
r28$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 1 | a) [RMSE]`)
r28$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 1 | b) [RMSE]`)
r28$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 2 | a) [RMSE]`)
r28$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (Mod 2 | b) [RMSE]`)
r28$Demanda <- gsub("[.]", ",",r28$Demanda)
r28$Best.ERROR.MAPE <- gsub("[.]", ",",r28$Best.ERROR.MAPE)
r28$Best.ERROR.RMSE <- gsub("[.]", ",",r28$Best.ERROR.RMSE)
# r28$Real <- gsub("[.]", ",",r28$Real)

r29$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 1 | a) [MAPE]`)
r29$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 1 | b) [MAPE]`)
r29$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 2 | a) [MAPE]`)
r29$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 2 | b) [MAPE]`)
r29$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 1 | a) [RMSE]`)
r29$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 1 | b) [RMSE]`)
r29$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 2 | a) [RMSE]`)
r29$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (Mod 2 | b) [RMSE]`)
r29$Demanda <- gsub("[.]", ",",r29$Demanda)
r29$Best.ERROR.MAPE <- gsub("[.]", ",",r29$Best.ERROR.MAPE)
r29$Best.ERROR.RMSE <- gsub("[.]", ",",r29$Best.ERROR.RMSE)

r30$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 1 | a) [MAPE]`)
r30$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 1 | b) [MAPE]`)
r30$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 2 | a) [MAPE]`)
r30$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 2 | b) [MAPE]`)
r30$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 1 | a) [RMSE]`)
r30$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 1 | b) [RMSE]`)
r30$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 2 | a) [RMSE]`)
r30$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (Mod 2 | b) [RMSE]`)
r30$Demanda <- gsub("[.]", ",",r30$Demanda)
r30$Best.ERROR.MAPE <- gsub("[.]", ",",r30$Best.ERROR.MAPE)
r30$Best.ERROR.RMSE <- gsub("[.]", ",",r30$Best.ERROR.RMSE)

r31$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 1 | a) [MAPE]`)
r31$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 1 | b) [MAPE]`)
r31$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 2 | a) [MAPE]`)
r31$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 2 | b) [MAPE]`)
r31$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 1 | a) [RMSE]`)
r31$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 1 | b) [RMSE]`)
r31$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 2 | a) [RMSE]`)
r31$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (Mod 2 | b) [RMSE]`)
r31$Demanda <- gsub("[.]", ",",r31$Demanda)
r31$Best.ERROR.MAPE <- gsub("[.]", ",",r31$Best.ERROR.MAPE)
r31$Best.ERROR.RMSE <- gsub("[.]", ",",r31$Best.ERROR.RMSE)

r01$`Predicao Guia (Mod 1 | a) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 1 | a) [MAPE]`)
r01$`Predicao Guia (Mod 1 | b) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 1 | b) [MAPE]`)
r01$`Predicao Guia (Mod 2 | a) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 2 | a) [MAPE]`)
r01$`Predicao Guia (Mod 2 | b) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 2 | b) [MAPE]`)
r01$`Predicao Guia (Mod 1 | a) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 1 | a) [RMSE]`)
r01$`Predicao Guia (Mod 1 | b) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 1 | b) [RMSE]`)
r01$`Predicao Guia (Mod 2 | a) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 2 | a) [RMSE]`)
r01$`Predicao Guia (Mod 2 | b) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (Mod 2 | b) [RMSE]`)
r01$Demanda <- gsub("[.]", ",",r01$Demanda)
r01$Best.ERROR.MAPE <- gsub("[.]", ",",r01$Best.ERROR.MAPE)
r01$Best.ERROR.RMSE <- gsub("[.]", ",",r01$Best.ERROR.RMSE)
############

###########
## Files ##
###########
r26$Data.do.Guia <- as.Date('2019-08-04')
r27$Data.do.Guia <- as.Date('2019-08-04')
r28$Data.do.Guia <- as.Date('2019-08-04')
r29$Data.do.Guia <- as.Date('2019-08-04')
r30$Data.do.Guia <- as.Date('2019-08-04')
r31$Data.do.Guia <- as.Date('2019-08-04')
r01$Data.do.Guia <- as.Date('2019-08-04')

r26 <- r26[,c(3,24,1,2,4:17,20:23,18,19)]
r27 <- r27[,c(3,24,1,2,4:17,20:23,18,19)]
r28 <- r28[,c(3,23,1,2,4:17,19,20,21,22,18)]
r29 <- r29[,c(3,23,1,2,4:17,19,20,21,22,18)]
r30 <- r30[,c(3,23,1,2,4:17,19,20,21,22,18)]
r31 <- r31[,c(3,23,1,2,4:17,19,20,21,22,18)]
r01 <- r01[,c(3,23,1,2,4:17,19,20,21,22,18)]

write.csv(r26, 'data/2019-08-05.csv', row.names = F)
write.csv(r27, 'data/2019-08-06.csv', row.names = F)
write.csv(r28, 'data/2019-08-07.csv', row.names = F)
write.csv(r29, 'data/2019-08-08.csv', row.names = F)
write.csv(r30, 'data/2019-08-09.csv', row.names = F)
write.csv(r31, 'data/2019-08-10.csv', row.names = F)
write.csv(r01, 'data/2019-08-11.csv', row.names = F)
###########



