df.13 <- df.prev[,c('plu', 'pred.d1')]
df.14 <- df.prev[,c('plu', 'pred.d2')]
df.15 <- df.prev[,c('plu', 'pred.d3')]
df.16 <- df.prev[,c('plu', 'pred.d4')]

df.13 <- merge(df.13, df.prev.dem[,c( "plu", "2019-07-13")])
df.14 <- merge(df.14, df.prev.dem[,c( "plu", "2019-07-14")])
df.15 <- merge(df.15, df.prev.dem[,c( "plu", "2019-07-15")])
df.16 <- merge(df.16, df.prev.dem[,c( "plu", "2019-07-16")])

df.13 <- merge(df.13, df.measures)
df.14 <- merge(df.14, df.measures)
df.15 <- merge(df.15, df.measures)
df.16 <- merge(df.16, df.measures)

names(df.13)[2:3] <- c('Predicao Guia', 'Demanda')
names(df.14)[2:3] <- c('Predicao Guia', 'Demanda')
names(df.15)[2:3] <- c('Predicao Guia', 'Demanda')
names(df.16)[2:3] <- c('Predicao Guia', 'Demanda')

df.13 <- df.13[,c(4,1,10,2,3,5:9)]
df.14 <- df.14[,c(4,1,10,2,3,5:9)]
df.15 <- df.15[,c(4,1,10,2,3,5:9)]
df.16 <- df.16[,c(4,1,10,2,3,5:9)]

real <- aggregate(df$QTD_VENDIDA_PROD ~ df$plu + df$datvenda, data = df[df$codloja == 1302,], FUN = sum)
real <- real[real$`df$datvenda` >= '2019-07-13',]
names(real)[1] <- 'plu'
names(real)[3] <- 'QTDE Real'

df.13 <- merge(df.13, real[real$`df$datvenda` == '2019-07-13',c(1,3)], all.x = T)
df.14 <- merge(df.14, real[real$`df$datvenda` == '2019-07-14',c(1,3)], all.x = T)

df.13$`Predição Guia` <- gsub("[.]", ",", df.13$`Predição Guia`)
df.14$`Predição Guia` <- gsub("[.]", ",", df.14$`Predição Guia`)
df.15$`Predição Guia` <- gsub("[.]", ",", df.15$`Predição Guia`)
df.16$`Predição Guia` <- gsub("[.]", ",", df.16$`Predição Guia`)

df.13$Demanda <- gsub("[.]", ",", df.13$Demanda)
df.14$Demanda <- gsub("[.]", ",", df.14$Demanda)
df.15$Demanda <- gsub("[.]", ",", df.15$Demanda)
df.16$Demanda <- gsub("[.]", ",", df.16$Demanda)

df.13$`QTDE Real` <- gsub("[.]", ",", df.13$`QTDE Real`)
df.14$`QTDE Real` <- gsub("[.]", ",", df.14$`QTDE Real`)


write.csv(df.13, '2019-07-13.csv',row.names = F, sep = ';', na = '')
write.csv(df.14, '2019-07-14.csv',row.names = F, sep = ';', na = '')
write.csv(df.15, '2019-07-15.csv',row.names = F, sep = ';', na = '')
write.csv(df.16, '2019-07-16.csv',row.names = F, sep = ';', na = '')
