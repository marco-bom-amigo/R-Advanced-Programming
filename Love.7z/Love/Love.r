#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
#################

#################
## Le os dados ##
#################
df     <- read.csv('data/df.csv'    , stringsAsFactors = F)
events <- read.csv('data/love.events.csv', stringsAsFactors = F, sep = ',')
#################

###########
## Preco ##
###########
df$preco <- round(df$VAL_TOT_VENDA_PROD / df$QTD_VENDIDA_PROD)
###########

##########
## Date ##
##########
df$datvenda <- as.Date(df$datvenda)
##########

############
## Events ##
############
events$Date <- gsub(' de ', '/',events$Date)

events$Date <- gsub('Jan', '01', events$Date)
events$Date <- gsub('Fev', '02', events$Date)
events$Date <- gsub('Mar', '03', events$Date)
events$Date <- gsub('Abr', '04', events$Date)
events$Date <- gsub('Mai', '05', events$Date)
events$Date <- gsub('Jun', '06', events$Date)
events$Date <- gsub('Jul', '07', events$Date)
events$Date <- gsub('Ago', '08', events$Date)
events$Date <- gsub('Set', '09', events$Date)
events$Date <- gsub('Out', '10', events$Date)
events$Date <- gsub('Nov', '11', events$Date)
events$Date <- gsub('Dez', '12', events$Date)

events$Date <- paste(events$Date, events$Year, sep = '/')
events$Date <- dmy(events$Date)

events$Name <- gsub(' ', '_', events$Name)
events$Name <- gsub("'s_Day", '', events$Name)
events$Name <- gsub("[(]", '', events$Name)
events$Name <- gsub("[)]", '', events$Name)
events$Name <- gsub("_Day", '', events$Name)
events$Name <- gsub("_/_May", '', events$Name)
events$Name <- gsub("_/_", '_', events$Name)
events$Name <- gsub("'s", '', events$Name)

unique(events$Name)
############

###############
## Events =) ##
###############
events$Type <- NULL
year    <- unique(events$Year)
feriado <- unique(events$Name)
for (y in year) {
  for (i in feriado) {
    dt <- events[events$Name == i & events$Year == y,]$Date
    for (j in 1:7) {
      if (sum(events$Date == dt - days(j)) == 0) {
        events <- rbind(events, data.frame(Date = dt - days(j), Name = paste(i, 'b', j, sep = '_'), Year = y))  
      }
      if (sum(events$Data == dt + days(j)) == 0) {
        events <- rbind(events, data.frame(Date = dt + days(j), Name = paste(i, 'b', j, sep = '_'), Year = y))  
      }
    }; rm(j)
  }
}; rm(y); rm(i); rm(year); rm(feriado); rm(dt)

events$Year <- NULL
dm <- as.data.frame(dummy(events$Name))
names(dm) <- gsub('Name)', '', names(dm))
events <- cbind(events$Date, dm)
names(events)[1] <- 'Data'
rm(dm)

dt <- unique(events$Data)
for (i in 1:length(dt)) {
  if (exists('df.events')) {
    df.events <- rbind(df.events, data.frame(Data = dt[i], t(colSums(events[events$Data == dt[i],-1]))))
  } else {
    df.events <- data.frame(Data = as.Date(dt[i]), t(colSums(events[events$Data == i,-1])))
  }
}; rm(i)
events <- df.events; rm(df.events); rm(dt)
###############

#############################
## Forecast por PLU e Loja ##
#############################
for (loja in unique(df$codloja)) {
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    
    ######################
    ## Descricao do PLU ##
    ######################
    desc <- list( NOM_SECAO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_SECAO   , 1)
                , NOM_CATEG    = head(df[df$codloja == loja & df$plu == plu,]$NOM_CATEG   , 1)
                , NOM_SUBCATEG = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBCATEG, 1)
                , NOM_GRUPO    = head(df[df$codloja == loja & df$plu == plu,]$NOM_GRUPO   , 1)
                , NOM_SUBGRUPO = head(df[df$codloja == loja & df$plu == plu,]$NOM_SUBGRUPO, 1)
                , NOM_PROD     = head(df[df$codloja == loja & df$plu == plu,]$NOM_PROD    , 1)
                )
    ######################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a   <- df[df$codloja == loja & df$plu == plu,]
    df.a.l <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = length); names(df.a.l)[2] <- 'QTD_TRANS'
    df.a.s <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    df.a   <- merge( df.a.l
                   , df.a.s
                   ); rm(df.a.l); rm(df.a.s)
    df.a$MEAN_QTD_VENDIDA_PROD <- df.a$QTD_VENDIDA_PROD / df.a$QTD_TRANS
    #########################
    
    ###########################
    ## Extract Date Features ##
    ###########################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , max(df.a$datvenda)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ###########################
    sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)

    if (exists('df.measures')) {
      df.measures <- rbind(df.measures, data.frame( COD_LOJA     = loja
                                                  , plu          = plu
                                                  , NOM_SECAO    = desc$NOM_SECAO
                                                  , NOM_CATEG    = desc$NOM_CATEG
                                                  , NOM_SUBCATEG = desc$NOM_SUBCATEG
                                                  , NOM_GRUPO    = desc$NOM_GRUPO
                                                  , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                                                  , NOM_PROD     = desc$NOM_PROD
                                                  , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                                                  , N.DAYS       = nrow(df.a)
                                                  , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                                                  , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                                                  , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                                                  )
                          )
    } else {
      df.measures <- data.frame( COD_LOJA     = loja
                               , plu          = plu
                               , NOM_SECAO    = desc$NOM_SECAO
                               , NOM_CATEG    = desc$NOM_CATEG
                               , NOM_SUBCATEG = desc$NOM_SUBCATEG
                               , NOM_GRUPO    = desc$NOM_GRUPO
                               , NOM_SUBGRUPO = desc$NOM_SUBGRUPO
                               , NOM_PROD     = desc$NOM_PROD
                               , FILL.P       = round((sum(!is.na(df.a$QTD_VENDIDA_PROD)) / nrow(df.a)) * 100, 2)
                               , N.DAYS       = nrow(df.a)
                               , S.DAYS       = sum(!is.na(df.a$QTD_VENDIDA_PROD))
                               , N.TRANS      = nrow(df[df$codloja == loja & df$plu == plu,])
                               , PROFIT       = sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_VENDA_PROD) - sum(df[df$codloja == loja & df$plu == plu,]$VAL_TOT_DESC)
                               )
    }
    
  }
}; rm(loja); rm(plu); rm(df.a); rm(desc); rm(n.plu); rm(tot)




###########
## Files ##
###########
write.csv(df.measures, 'data/df.measures.csv', row.names = F)
write.csv(events     , 'data/df.events.csv'  , row.names = F)

setwd("~/Guia de Produção/Love")
df.measures <- read.csv('data/df.measures.csv')
###########

#############
## Results ##
#############
setwd("~/Guia de Produção/Love/results/MLR")
files <- list.files()
result <- read.csv(files[1])
for (f in files[2:6]) {
  result <- rbind(result, read.csv(f))
}
names(result)[3] <- 'mlr'
df.measures <- merge( df.measures
                    , result
                    , all.x = T
                    )

setwd("~/Guia de Produção/Love/results/MLRo")
files <- list.files()
result <- read.csv(files[1])
for (f in files[2:6]) {
  result <- rbind(result, read.csv(f))
}
names(result)[3] <- 'mlro'
df.measures <- merge( df.measures
                    , result
                    , all.x = T
                    )

setwd("~/Guia de Produção/Love/results/RFR")
files <- list.files()
result <- read.csv(files[1])
for (f in files[2:6]) {
  result <- rbind(result, read.csv(f))
}
names(result)[3] <- 'rfr'
df.measures <- merge( df.measures
                    , result
                    , all.x = T
                    )
 
setwd("~/Guia de Produção/Love/results/RFRo")
files <- list.files()
result <- read.csv(files[1])
for (f in files[2:6]) {
  result <- rbind(result, read.csv(f))
}
names(result)[3] <- 'rfro'
result <- unique(result)
df.measures <- merge( df.measures
                    , result
                    , all.x = T
                    )
#############

##########
## Mape ##
##########
df.measures$MAPE     <- 0
df.measures$Accuracy <- 0
df.measures$model    <- ''

for (i in 1:nrow(df.measures)) {
  df.measures[i,]$MAPE  <- as.numeric((df.measures[i,c(14:17)][which.min(df.measures[i,c(14:17)])[[1]][1]]))
  df.measures[i,]$model <- names(which.min(df.measures[i,c(14:17)]))
}

df.measures$Accuracy <- 100 - df.measures$MAPE
##########

stats <- boxplot(df.measures$Accuracy, plot = F)$stats
sum(df.measures$Accuracy < stats[1])

setwd("~/Guia de Produção/Love/data")
write.csv(df.measures, 'result.csv', row.names = F)

rm(i); rm(f); rm(files); rm(stats); rm(result)


















