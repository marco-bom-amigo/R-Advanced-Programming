#################
## Bibliotecas ##
#################
library(lubridate)
library(dummies)
library(stringr)
#################

models <- list(date = Sys.Date())
for (loja in unique(df$codloja)[1]) {
  
  tot <- length(unique(df[df$codloja == loja,]$plu))
  n.plu <- 0
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    
    n.plu <- n.plu + 1
      
    #################
    ## Current Row ##
    #################
    cat(paste('\n(', n.plu, ' / ', tot, ')', sep = ''))
    cat(paste('\n', loja, ' | ', plu, sep = ''))
    #################
    
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a <- df[df$codloja == loja & df$plu == plu, c("datvenda", "QTD_VENDIDA_PROD")]
    df.a <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    #########################

    ##################
    ## All Dates <3 ##
    ##################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , max(df.a$datvenda)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ##################
    
    ############
    ## Events ##
    ############
    df.a <- merge( df.a
                 , events
                 , by.x = 'datvenda'
                 , by.y = 'Data'
                 , all.x = T
                 )
    for (column in names(df.a)[3:234]) {
      df.a[is.na(df.a[,column]),column] <- 0
    }; rm(column)
    ############
    
    ###############
    ## Empty ='( ##
    ###############
    df.a$QTD_VENDIDA_PROD[is.na(df.a$QTD_VENDIDA_PROD)] <- 0
    ###############

    ###########
    ## Preco ##
    ###########
    preco <- df[df$codloja == loja & df$plu == plu,]
    preco <- preco[order(preco$datvenda),]
    preco <- preco[!duplicated(preco$preco),c("datvenda", "preco")]
    df.a <- merge( df.a
                 , preco
                 , all.x = T
                 ); rm(preco)
    
    l.preco <- df.a[1,]$preco
    if (nrow(df.a) > 1) {
      for (i in 2:nrow(df.a)) {
        if (is.na(df.a[i,]$preco)) {
          df.a[i,]$preco <- l.preco
        } else {
          l.preco <- df.a[i,]$preco
        }
      }; rm(l.preco); rm(i)
    }
    ###########    

    ##########################
    ## Auto Regressive...?! ##
    ##########################
    if (nrow(df.a) > 28) {
      
      df.m.28 <- df.a[1:(nrow(df.a)-28),]$QTD_VENDIDA_PROD
      df.m.27 <- df.a[2:(nrow(df.a)-27),]$QTD_VENDIDA_PROD
      df.m.26 <- df.a[3:(nrow(df.a)-26),]$QTD_VENDIDA_PROD
      df.m.25 <- df.a[4:(nrow(df.a)-25),]$QTD_VENDIDA_PROD
      df.m.24 <- df.a[5:(nrow(df.a)-24),]$QTD_VENDIDA_PROD
      df.m.23 <- df.a[6:(nrow(df.a)-23),]$QTD_VENDIDA_PROD
      df.m.22 <- df.a[7:(nrow(df.a)-22),]$QTD_VENDIDA_PROD
      
      df.m.21 <- df.a[8: (nrow(df.a)-21),]$QTD_VENDIDA_PROD
      df.m.20 <- df.a[9: (nrow(df.a)-20),]$QTD_VENDIDA_PROD
      df.m.19 <- df.a[10:(nrow(df.a)-19),]$QTD_VENDIDA_PROD
      df.m.18 <- df.a[11:(nrow(df.a)-18),]$QTD_VENDIDA_PROD
      df.m.17 <- df.a[12:(nrow(df.a)-17),]$QTD_VENDIDA_PROD
      df.m.16 <- df.a[13:(nrow(df.a)-16),]$QTD_VENDIDA_PROD
      df.m.15 <- df.a[14:(nrow(df.a)-15),]$QTD_VENDIDA_PROD
      
      df.m.14 <- df.a[15:(nrow(df.a)-14),]$QTD_VENDIDA_PROD
      df.m.13 <- df.a[16:(nrow(df.a)-13),]$QTD_VENDIDA_PROD
      df.m.12 <- df.a[17:(nrow(df.a)-12),]$QTD_VENDIDA_PROD
      df.m.11 <- df.a[18:(nrow(df.a)-11),]$QTD_VENDIDA_PROD
      df.m.10 <- df.a[19:(nrow(df.a)-10),]$QTD_VENDIDA_PROD
      df.m.9  <- df.a[20:(nrow(df.a)-9 ),]$QTD_VENDIDA_PROD
      df.m.8  <- df.a[21:(nrow(df.a)-8 ),]$QTD_VENDIDA_PROD

      df.m.7 <- df.a[22:(nrow(df.a)-7),]$QTD_VENDIDA_PROD
      df.m.6 <- df.a[23:(nrow(df.a)-6),]$QTD_VENDIDA_PROD
      df.m.5 <- df.a[24:(nrow(df.a)-5),]$QTD_VENDIDA_PROD
      df.m.4 <- df.a[25:(nrow(df.a)-4),]$QTD_VENDIDA_PROD
      df.m.3 <- df.a[26:(nrow(df.a)-3),]$QTD_VENDIDA_PROD
      df.m.2 <- df.a[27:(nrow(df.a)-2),]$QTD_VENDIDA_PROD
      df.m.1 <- df.a[28:(nrow(df.a)-1),]$QTD_VENDIDA_PROD
      
      df.a <- df.a[29:nrow(df.a),]
      
      df.a$m.1 <- df.m.1
      df.a$m.2 <- df.m.2
      df.a$m.3 <- df.m.3
      df.a$m.4 <- df.m.4
      df.a$m.5 <- df.m.5
      df.a$m.6 <- df.m.6
      df.a$m.7 <- df.m.7
      
      df.a$m.8  <- df.m.8
      df.a$m.9  <- df.m.9
      df.a$m.10 <- df.m.10
      df.a$m.11 <- df.m.11
      df.a$m.12 <- df.m.12
      df.a$m.13 <- df.m.13
      df.a$m.14 <- df.m.14

      df.a$m.15 <- df.m.15
      df.a$m.16 <- df.m.16
      df.a$m.17 <- df.m.17
      df.a$m.18 <- df.m.18
      df.a$m.19 <- df.m.19
      df.a$m.20 <- df.m.20
      df.a$m.21 <- df.m.22
      
      df.a$m.22 <- df.m.22
      df.a$m.23 <- df.m.23
      df.a$m.24 <- df.m.24
      df.a$m.25 <- df.m.25
      df.a$m.26 <- df.m.26
      df.a$m.27 <- df.m.27
      df.a$m.28 <- df.m.28

      df.a$previous.week.mean <- 0
      df.a$previous.week.sum  <- 0
      
      df.a$previous.2.week.mean <- 0
      df.a$previous.2.week.sum  <- 0
      
      df.a$previous.3.week.mean <- 0
      df.a$previous.3.week.sum  <- 0
      
      df.a$previous.4.week.mean <- 0
      df.a$previous.4.week.sum  <- 0
      
      for (i in 1:nrow(df.a)) {
        df.a[i,]$previous.week.mean <- mean(as.matrix(df.a[i, c('m.1', 'm.2', 'm.3', 'm.4', 'm.5', 'm.6', 'm.7')]), na.rm = T)
        df.a[i,]$previous.week.sum  <- sum( as.matrix(df.a[i, c('m.1', 'm.2', 'm.3', 'm.4', 'm.5', 'm.6', 'm.7')]), na.rm = T)
        
        df.a[i,]$previous.2.week.mean <- mean(as.matrix(df.a[i, c('m.8', 'm.9', 'm.10', 'm.11', 'm.12', 'm.13', 'm.14')]), na.rm = T)
        df.a[i,]$previous.2.week.sum  <- sum( as.matrix(df.a[i, c('m.8', 'm.9', 'm.10', 'm.11', 'm.12', 'm.13', 'm.14')]), na.rm = T)
        
        df.a[i,]$previous.3.week.mean <- mean(as.matrix(df.a[i, c('m.15', 'm.16', 'm.17', 'm.18', 'm.19', 'm.20', 'm.21')]), na.rm = T)
        df.a[i,]$previous.3.week.sum  <- sum( as.matrix(df.a[i, c('m.15', 'm.16', 'm.17', 'm.18', 'm.19', 'm.20', 'm.21')]), na.rm = T)
        
        df.a[i,]$previous.4.week.mean <- mean(as.matrix(df.a[i, c('m.22', 'm.23', 'm.24', 'm.25', 'm.26', 'm.27', 'm.28')]), na.rm = T)
        df.a[i,]$previous.4.week.sum  <- sum( as.matrix(df.a[i, c('m.22', 'm.23', 'm.24', 'm.25', 'm.26', 'm.27', 'm.28')]), na.rm = T)
        
      }; rm(i)
      rm(list = c('df.m.7','df.m.6','df.m.5','df.m.4','df.m.3','df.m.2','df.m.1'))
      rm(list = c('df.m.14','df.m.13','df.m.12','df.m.11','df.m.10','df.m.9','df.m.8'))
      rm(list = c('df.m.15','df.m.16','df.m.17','df.m.18','df.m.19','df.m.20','df.m.21'))
      rm(list = c('df.m.22','df.m.23','df.m.24','df.m.25','df.m.26','df.m.27','df.m.28'))
    }
    ##########################

    ###################
    ## Date Features ##
    ###################
    df.a$year  <- year(df.a$datvenda)
    df.a$month <- month(df.a$datvenda)
    df.a$wday  <- as.POSIXlt(df.a$datvenda)$wday
    df.a$day   <- day(df.a$datvenda)
    ###################
    
    ##################
    ## No da Semana ##
    ##################
    week <- 0
    p.month <- 0
    df.a$week <- 0
    for (i in 1:nrow(df.a)) {
      if (p.month != df.a[i,]$month) {
        p.month <- df.a[i,]$month
        week <- 0
      }
      df.a[i,]$week <- week
      if (df.a[i,]$wday == 6) {
        week <- week + 1
      }
    }; rm(week); rm(i); rm(p.month)
    ##################
    
    ################
    ## Dummies <3 ##
    ################
    w.o.label <- c("wday)0", "wday)1", "wday)2", "wday)3", "wday)4", "wday)5", "wday)6")
    w.label <- c('dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab')
    dm <- as.data.frame(dummy(df.a$wday))
    names(dm) <- w.label[match(names(dm), w.o.label)]
    df.a <- cbind(df.a, dm)

    m.o.label <- c("month)1", "month)2", "month)3", "month)4", "month)5", "month)6", "month)7", "month)8", "month)9", "month)10", "month)11", "month)12")
    m.label <- c('Janeiro','Fevereiro','Marco','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro')   
    dm <- as.data.frame(dummy(df.a$month))
    names(dm) <- m.label[match(names(dm), m.o.label)]
    df.a <- cbind(df.a, dm)
    rm(list = c('dm', 'w.o.label', 'w.label', 'm.o.label', 'm.label'))
    ################
    
    df.a$HASH <- as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))
    f <- sort(unique(as.numeric(paste(df.a$year, str_pad(df.a$month, pad = '0', side = 'left', width = 2), sep = ''))))
    
    MAPE <- Inf
    for (h in f) {
      df.h <- df.a[df.a$HASH >= h,]
      df.h <- df.h[,-length(df.h)]

      ##############
      ## Outliers ##
      ##############
      stats <- boxplot(df.h$QTD_VENDIDA_PROD[df.h$QTD_VENDIDA_PROD > 0], plot = F)$stats
      row.names(df.h) <- NULL
      df.out <- df.h[df.h$QTD_VENDIDA_PROD > stats[5],]
      if (nrow(df.out) > 0) {
        for (i in 1:nrow(df.out)) {
          mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$wday  == df.out[i,]$wday & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)
          if (is.na(mn)) {mn <- mean(df.h[ df.h$year  == df.out[i,]$year & df.h$month == df.out[i,]$month & df.h$QTD_VENDIDA_PROD < stats[5] , ]$QTD_VENDIDA_PROD)}
          if (!is.na(mn)) {
            df.h[as.numeric(row.names(df.out[i,])),]$QTD_VENDIDA_PROD <- mn
          }
        }; rm(i); rm(mn)
      }; rm(df.out); rm(stats)
      ###################
      
      ##############################
      ## Sazonalidade e Tendencia ##
      ##############################
      if (nrow(df.h) > 14) {
        stl  <- as.data.frame(stl(ts(df.h$QTD_VENDIDA_PROD, frequency = 7), s.window = 7)$time.series)
        df.h <- cbind(df.h, stl[,c('seasonal', 'trend')])
        rm(stl)
      }
      ##############################

      if (nrow(df.h) > 7) {
        df.train <- df.h[1:(nrow(df.h)-3),]
        df.test  <- df.h[(nrow(df.h)-2):nrow(df.h),]
        if (sum(df.train$QTD_VENDIDA_PROD) != 0) {
          mod <- lm(QTD_VENDIDA_PROD ~ ., data = df.train)
          coef <- as.data.frame(coef(summary(mod)))
        }
      }
      while (!is.null(dim(df.h)) & !sum(is.na(coef[-1,]$`Pr(>|t|)`)) == length(coef[-1,]$`Pr(>|t|)`)) {
        for (l in 1:4) {
          if (nrow(df.h) > 5) {
            df.train <- df.h[1:(nrow(df.h)-3),]
            df.test  <- df.h[(nrow(df.h)-2):nrow(df.h),]
          }
          if (l > 2) {
              df.train$month <- NULL
              df.train$wday  <- NULL
              df.test$month  <- NULL
              df.test$wday   <- NULL
            }
          if (l %in% c(2,3)) {
            df.train$trend    <- NULL
            df.train$seasonal <- NULL
            df.test$trend     <- NULL
            df.test$seasonal  <- NULL
          }
          
          tryCatch({
            mod <- lm(QTD_VENDIDA_PROD ~ ., data = df.train)
            pred <- predict(mod, df.test)
            real <- df.test$QTD_VENDIDA_PROD
            indx <- real == 0
            pred[pred < 0] <- 0
            pred[indx] <- pred[indx] + 1
            real[indx] <- real[indx] + 1
            if (mean((abs(real - pred)/real)) * 100 < MAPE) {
              MAPE <- round(mean((abs(real - pred)/real)) * 100, 2)
              models[[paste(loja, plu, sep = '.')]] <- list( model = mod
                                                           , h     = h
                                                           , featr = names(df.train)
                                                           , MAPE  = MAPE
                                                           )
            }
          }, error = function(cond) {
          })
                
        }
        coef <- as.data.frame(coef(summary(mod)))
        y <- df.h$QTD_VENDIDA_PROD
        df.h <- df.h[,c(names(df.h)[names(df.h) %in% row.names(coef(summary(mod)))[-1]],'QTD_VENDIDA_PROD')]
        if (!sum(is.na(coef[-1,]$`Pr(>|t|)`)) == length(coef[-1,]$`Pr(>|t|)`)) {
          df.h <- df.h[,-(which.max(coef[-1,]$`Pr(>|t|)`))]
        }
        df.h$QTD_VENDIDA_PROD <- y
      }
    }
    cat(paste('\n', MAPE, '\n', sep = ''))
    if (exists('result')) {
      result <- rbind(result, data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE))
    } else {
      result <- data.frame(COD_LOJA = loja, plu = plu, MAPE = MAPE)
    }
  }
}; rm(f); rm(h); rm(indx); rm(l); rm(y); rm(loja); rm(plu); rm(pred); rm(real); rm(MAPE); rm(mod); rm(df.train); rm(df.test); rm(df.a); rm(df.h); rm(coef); rm(n.plu); rm(tot)

write.csv( result
           , 'results/MLR/mlr1302.csv'
           , row.names = F
)

saveRDS( models
         , "models/mlr/mlr1302.rds"
)

