# for (loja in unique(df$codloja)) {
for (loja in c(1302)) {  
    
  tot <- length(unique(df[df$codloja == loja,]$plu))
  ind <- 0
  
  for (plu in unique(df[df$codloja == loja,]$plu)) {
    ind <- ind + 1
    cat('\n', ind, '/', tot)
    #########################
    ## Data Frame Auxiliar ##
    #########################
    df.a <- df[df$codloja == loja & df$plu == plu, c("datvenda", "QTD_VENDIDA_PROD")]
    df.a <- aggregate(QTD_VENDIDA_PROD ~ datvenda, data = df.a, FUN = sum)
    #########################
    
    ##################
    ## All Dates <3 ##
    ##################
    df.a <- merge( data.frame( datvenda = seq( min(df.a$datvenda)
                                             , Sys.Date() - days(3)
                                             , by = 1
                                             )
                             )
                 , df.a
                 , all.x = T
                 )
    ##################
    
    ###############
    ## Empty ='( ##
    ###############
    df.a$QTD_VENDIDA_PROD[is.na(df.a$QTD_VENDIDA_PROD)] <- 0
    ###############
    
    df.a$wday <- as.POSIXlt(df.a$datvenda)$wday
    df.t <- tail(df.a, 70)
    
    means <- list( mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(1))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(2))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(3))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(4))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(5))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(6))$wday,]$QTD_VENDIDA_PROD)
                 , mean(df.t[df.t$wday == as.POSIXlt(max(df.a$datvenda) + days(7))$wday,]$QTD_VENDIDA_PROD)
                 )
    means <- data.frame(means)
    names(means) <- seq(max(df.a$datvenda) + days(1), max(df.a$datvenda) + days(7), by = 1)
    
    if (!exists('bench')) {
      bench <- cbind(data.frame(COD_LOJA = loja, plu = plu), means)
    } else {
      bench <- rbind(bench, cbind(data.frame(COD_LOJA = loja, plu = plu), means))
    }
    
  }
}
