PrevDem <- data.frame(PrevDem)

for (loja in unique(PrevDem$COD_LOCAL)) {


tot <- length(unique(PrevDem[PrevDem$COD_LOCAL == loja,]$COD_PLU))
ind <- 0
for (plu in unique(PrevDem[PrevDem$COD_LOCAL == loja,]$COD_PLU)) {
  ind <- ind + 1
  cat('\n', ind, '/', tot)
  df.a <- data.frame(t(PrevDem[PrevDem$COD_LOCAL == loja & PrevDem$COD_PLU == plu,c(3,4)]))[2,]
  names(df.a) <- as.matrix(data.frame(t(PrevDem[PrevDem$COD_LOCAL == loja & PrevDem$COD_PLU == plu,c(3,4)]))[1,])
  if (exists('df.prev.dem')) {
    if (length(cbind(plu = plu, df.a)) >= 5) {
      df.prev.dem <- rbind(df.prev.dem, cbind(COD_LOJA = loja, plu = plu, df.a))  
    }
  } else {
    df.prev.dem <- cbind(COD_LOJA = loja, plu = plu, df.a)
  }
  
}; rm(df.a); rm(tot); rm(ind); rm(plu)

}
