PrevDem <- data.frame(PrevDem)

tot <- length(unique(PrevDem$COD_PLU))
ind <- 0
for (plu in unique(PrevDem$COD_PLU)) {
  ind <- ind + 1
  cat('\n', ind, '/', tot)
  df.a <- data.frame(t(PrevDem[PrevDem$COD_PLU == plu,c(3,4)]))[2,]
  names(df.a) <- as.matrix(data.frame(t(PrevDem[PrevDem$COD_PLU == plu,c(3,4)]))[1,])
  if (exists('df.prev.dem')) {
    if (length(cbind(plu = plu, df.a)) >= 4) {
      df.prev.dem <- rbind(df.prev.dem, cbind(plu = plu, df.a))  
    }
  } else {
    df.prev.dem <- cbind(plu = plu, df.a)
  }
  
}; rm(df.a); rm(tot); rm(ind); rm(plu)
