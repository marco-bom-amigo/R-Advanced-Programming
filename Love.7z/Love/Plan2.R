###############
## Read data ##
###############
files <- list.files('results')
files <- files[5:24]
m1a   <- read.csv(paste('results/', files[1], sep = ''), stringsAsFactors = F)
for (file in files[2:20]) {
  m1a <- rbind(m1a, read.csv(paste('results/', file, sep = ''), stringsAsFactors = F))
  
}; rm(file); rm(files)

id <- unique(m1a[,c('COD_LOJA', 'plu')])
for (i in 1:nrow(id)) {
  df.p <- m1a[m1a$COD_LOJA == id[i,]$COD_LOJA & m1a$plu == id[i,]$plu,]
  if (!exists('MAPE')) {
    MAPE <- df.p[which.min(df.p$MAPE),]
  } else {
    MAPE <- rbind(MAPE, df.p[which.min(df.p$MAPE),])
  }
}; rm(i); rm(df.p); rm(id); rm(m1a)

for (i in 1:nrow(id)) {
  df.p <- m1a[m1a$COD_LOJA == id[i,]$COD_LOJA & m1a$plu == id[i,]$plu,]
  if (!exists('RMSE')) {
    RMSE <- df.p[which.min(df.p$RMSE),]
  } else {
    RMSE <- rbind(RMSE, df.p[which.min(df.p$RMSE),])
  }
}; rm(i)
###############

########
## 26 ##
########
r26 <- merge(df.measures, MAPE[c(1,2,5,12)]); names(r26)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r26 <- merge(r26, RMSE[c(1,2,5,12)]); names(r26)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r26$date <- as.Date('2019-08-01') + days(1)
r26 <- r26[,c(13,1:12)]
r26 <- merge(r26, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r26)[14] <- 'Demanda'
r26 <- merge(r26, real, by.x = c("COD_LOJA", "plu", "date"), by.y = c("codloja", "plu", "datvenda"), all.x = T)
names(r26)[15] <- 'Real'

r26$Demanda[is.na(r26$Demanda)] <- 0
r26$Real[is.na(r26$Real)] <- 0
########

########
## 27 ##
########
r27 <- merge(df.measures, MAPE[c(1,2,6,13)]); names(r27)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r27 <- merge(r27, RMSE[c(1,2,6,13)]); names(r27)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r27$date <- as.Date('2019-08-01') + days(2)
r27 <- r27[,c(13,1:12)]
r27 <- merge(r27, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r27)[14] <- 'Demanda'
r27 <- merge(r27, real, by.x = c("COD_LOJA", "plu", "date"), by.y = c("codloja", "plu", "datvenda"), all.x = T)
names(r27)[15] <- 'Real'

r27$Demanda[is.na(r27$Demanda)] <- 0
r27$Real[is.na(r27$Real)] <- 0
########

########
## 28 ##
########
r28 <- merge(df.measures, MAPE[c(1,2,7,14)]); names(r28)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r28 <- merge(r28, RMSE[c(1,2,7,14)]); names(r28)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r28$date <- as.Date('2019-08-01') + days(3)
r28 <- r28[,c(13,1:12)]
r28 <- merge(r28, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r28)[14] <- 'Demanda'
r28 <- merge(r28, real, by.x = c("COD_LOJA", "plu", "date"), by.y = c("codloja", "plu", "datvenda"), all.x = T)
names(r28)[15] <- 'Real'

r28$Demanda[is.na(r28$Demanda)] <- 0
r28$Real[is.na(r28$Real)] <- 0
########

########
## 29 ##
########
r29 <- merge(df.measures, MAPE[c(1,2,8,15)]); names(r29)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r29 <- merge(r29, RMSE[c(1,2,8,15)]); names(r29)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r29$date <- as.Date('2019-08-01') + days(4)
r29 <- r29[,c(13,1:12)]
r29 <- merge(r29, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r29)[14] <- 'Demanda'

r29$Demanda[is.na(r29$Demanda)] <- 0
########

########
## 30 ##
########
r30 <- merge(df.measures, MAPE[c(1,2,9,16)]); names(r30)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r30 <- merge(r30, RMSE[c(1,2,9,16)]); names(r30)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r30$date <- as.Date('2019-08-01') + days(5)
r30 <- r30[,c(13,1:12)]
r30 <- merge(r30, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r30)[14] <- 'Demanda'

r30$Demanda[is.na(r30$Demanda)] <- 0
########

########
## 31 ##
########
r31 <- merge(df.measures, MAPE[c(1,2,10,17)]); names(r31)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r31 <- merge(r31, RMSE[c(1,2,10,17)]); names(r31)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r31$date <- as.Date('2019-08-01') + days(6)
r31 <- r31[,c(13,1:12)]
r31 <- merge(r31, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r31)[14] <- 'Demanda'

r31$Demanda[is.na(r31$Demanda)] <- 0
########

########
## 01 ##
########
r01 <- merge(df.measures, MAPE[c(1,2,11,18)]); names(r01)[9:10] <- c('Predicao Guia (MAPE) [MAPE]', 'Predicao Guia (MAPE) [RMSE]')
r01 <- merge(r01, RMSE[c(1,2,11,18)]); names(r01)[11:12] <- c('Predicao Guia (RMSE) [RMSE]', 'Predicao Guia (RMSE) [MAPE]')
r01$date <- as.Date('2019-08-01') + days(7)
r01 <- r01[,c(13,1:12)]
r01 <- merge(r01, PrevDem, by.x = c("COD_LOJA", "plu", "date"), by.y = c("COD_LOCAL", "COD_PLU", "DAT_DIA_CALEND"), all.x = T)
names(r01)[14] <- 'Demanda'

r01$Demanda[is.na(r01$Demanda)] <- 0
########

############
## Format ##
############
r26$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (MAPE) [MAPE]`)
r26$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (MAPE) [RMSE]`)
r26$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r26$`Predicao Guia (RMSE) [RMSE]`)
r26$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r26$`Predicao Guia (RMSE) [MAPE]`)
r26$Demanda <- gsub("[.]", ",",r26$Demanda)
r26$Real <- gsub("[.]", ",",r26$Real)

r27$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (MAPE) [MAPE]`)
r27$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (MAPE) [RMSE]`)
r27$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r27$`Predicao Guia (RMSE) [RMSE]`)
r27$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r27$`Predicao Guia (RMSE) [MAPE]`)
r27$Demanda <- gsub("[.]", ",",r27$Demanda)
r27$Real <- gsub("[.]", ",",r27$Real)

r28$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (MAPE) [MAPE]`)
r28$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (MAPE) [RMSE]`)
r28$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r28$`Predicao Guia (RMSE) [RMSE]`)
r28$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r28$`Predicao Guia (RMSE) [MAPE]`)
r28$Demanda <- gsub("[.]", ",",r28$Demanda)
r28$Real <- gsub("[.]", ",",r28$Real)

r29$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (MAPE) [MAPE]`)
r29$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (MAPE) [RMSE]`)
r29$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r29$`Predicao Guia (RMSE) [RMSE]`)
r29$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r29$`Predicao Guia (RMSE) [MAPE]`)
r29$Demanda <- gsub("[.]", ",",r29$Demanda)

r30$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (MAPE) [MAPE]`)
r30$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (MAPE) [RMSE]`)
r30$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r30$`Predicao Guia (RMSE) [RMSE]`)
r30$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r30$`Predicao Guia (RMSE) [MAPE]`)
r30$Demanda <- gsub("[.]", ",",r30$Demanda)

r31$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (MAPE) [MAPE]`)
r31$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (MAPE) [RMSE]`)
r31$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r31$`Predicao Guia (RMSE) [RMSE]`)
r31$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r31$`Predicao Guia (RMSE) [MAPE]`)
r31$Demanda <- gsub("[.]", ",",r31$Demanda)

r01$`Predicao Guia (MAPE) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (MAPE) [MAPE]`)
r01$`Predicao Guia (MAPE) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (MAPE) [RMSE]`)
r01$`Predicao Guia (RMSE) [RMSE]` <- gsub("[.]", ",",r01$`Predicao Guia (RMSE) [RMSE]`)
r01$`Predicao Guia (RMSE) [MAPE]` <- gsub("[.]", ",",r01$`Predicao Guia (RMSE) [MAPE]`)
r01$Demanda <- gsub("[.]", ",",r01$Demanda)
############

###########
## Files ##
###########
r26$Data.do.Guia <- as.Date('2019-08-01')
r27$Data.do.Guia <- as.Date('2019-08-01')
r28$Data.do.Guia <- as.Date('2019-08-01')
r29$Data.do.Guia <- as.Date('2019-08-01')
r30$Data.do.Guia <- as.Date('2019-08-01')
r31$Data.do.Guia <- as.Date('2019-08-01')
r01$Data.do.Guia <- as.Date('2019-08-01')

r26 <- r26[,c(16,3,1:2,4:15)]
r27 <- r27[,c(16,3,1:2,4:15)]
r28 <- r28[,c(16,3,1:2,4:15)]
r29 <- r29[,c(15,3,1:2,4:14)]
r30 <- r30[,c(15,3,1:2,4:14)]
r31 <- r31[,c(15,3,1:2,4:14)]
r01 <- r01[,c(15,3,1:2,4:14)]

write.csv(r26, 'data/2019-08-02.csv', row.names = F)
write.csv(r27, 'data/2019-08-03.csv', row.names = F)
write.csv(r28, 'data/2019-08-04.csv', row.names = F)
write.csv(r29, 'data/2019-08-05.csv', row.names = F)
write.csv(r30, 'data/2019-08-06.csv', row.names = F)
write.csv(r31, 'data/2019-08-07.csv', row.names = F)
write.csv(r01, 'data/2019-08-08.csv', row.names = F)
###########



