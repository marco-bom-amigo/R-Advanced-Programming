names(df.20)
names(df20)

r <- merge( df.20
          , df20
          , by.x = c("COD_LOJA", "plu")
          , by.y = c("codloja" , "plu")
          , all.x = T
          )
r$datvenda <- NULL
r$QTD_VENDIDA_PROD[is.na(r$QTD_VENDIDA_PROD)] <- 0

pred <- r$Demanda         #    Acc.   8.25
pred <- r$`Predicao Guia` #    Acc.  56.55
                          # Up Lift  48.3

pred[is.na(pred)] <- 0

real <- r$QTD_VENDIDA_PROD

pred <- as.numeric(gsub(",", ".", pred))
pred[pred < 0] <- 0
indx <- real == 0
pred[indx] <- pred[indx] + 1
real[indx] <- real[indx] + 1

100 - round(mean((abs(real - pred)/real)) * 100, 2)


